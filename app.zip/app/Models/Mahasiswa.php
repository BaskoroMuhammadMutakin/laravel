<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mahasiswa extends Model
{
    protected $primaryKey = 'NPM';
    public $incrementing  = false;
    protected $keyType    = 'string';

    protected $fillable = ['NPM', 'Nama', 'Alamat', 'Program_Studi'];
}