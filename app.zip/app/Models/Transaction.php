<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $fillable = [
        'user_id',
        'category_id',
        'amount',
        'transaction_date',
        'description'
    ];

    protected $casts = [
        'transaction_date' => 'date',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }
}