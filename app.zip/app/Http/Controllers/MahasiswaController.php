<?php

namespace App\Http\Controllers;

use App\Models\Mahasiswa;
use Illuminate\Http\Request;

class MahasiswaController extends Controller
{
    public function index()
    {
        $data = Mahasiswa::all();
        return view('mahasiswa.index', compact('data'));
    }

    public function create()
    {
        return view('mahasiswa.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'NPM'          => 'required|max:10|unique:mahasiswas,NPM',
            'Nama'         => 'required|max:100',
            'Alamat'       => 'nullable',
            'Program_Studi'=> 'nullable|max:50',
        ], [
            'NPM.required'  => 'NPM wajib diisi.',
            'NPM.unique'    => 'NPM sudah terdaftar.',
            'Nama.required' => 'Nama wajib diisi.',
        ]);

        Mahasiswa::create($request->all());

        return redirect()->route('mahasiswa.index')
            ->with('success', 'Data mahasiswa berhasil ditambahkan!');
    }

    public function edit($npm)
    {
        $mhs = Mahasiswa::findOrFail($npm);
        return view('mahasiswa.edit', compact('mhs'));
    }

    public function update(Request $request, $npm)
    {
        $request->validate([
            'Nama'          => 'required|max:100',
            'Alamat'        => 'nullable',
            'Program_Studi' => 'nullable|max:50',
        ]);

        $mhs = Mahasiswa::findOrFail($npm);
        $mhs->update($request->only(['Nama', 'Alamat', 'Program_Studi']));

        return redirect()->route('mahasiswa.index')
            ->with('success', 'Data mahasiswa berhasil diubah!');
    }

    public function destroy($npm)
    {
        Mahasiswa::findOrFail($npm)->delete();

        return redirect()->route('mahasiswa.index')
            ->with('success', 'Data mahasiswa berhasil dihapus!');
    }
}