<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\Category;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function index()
    {
        $transactions = Transaction::with('category')
            ->where('user_id', auth()->id())
            ->latest()
            ->get();

        // Hitung saldo: income dikurangi expense
        $totalBalance = Transaction::with('category')
            ->where('user_id', auth()->id())
            ->get()
            ->sum(function ($t) {
                return $t->category->type === 'income'
                    ? $t->amount
                    : -$t->amount;
            });

        return view('transactions.index', compact('transactions', 'totalBalance'));
    }

    public function create()
    {
        $categories = Category::all();
        return view('transactions.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'category_id'      => 'required|exists:categories,id',
            'amount'           => 'required|numeric|min:1',
            'transaction_date' => 'required|date',
            'description'      => 'nullable|string|max:255',
        ]);

        Transaction::create([
            'user_id'          => auth()->id(),   // pakai user yang sedang login
            'category_id'      => $request->category_id,
            'amount'           => $request->amount,
            'transaction_date' => $request->transaction_date,
            'description'      => $request->description,
        ]);

        return redirect()->route('transactions.index')
            ->with('success', 'Transaksi berhasil ditambahkan!');
    }
}