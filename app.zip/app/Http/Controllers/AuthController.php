<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class AuthController extends Controller
{
    // ── REGISTER ──
    public function register(Request $request)
    {
        $request->validate([
            'nama'     => 'required|string|max:100',
            'nik'      => 'required|digits:16|unique:users,nik',
            'email'    => 'required|email|unique:users,email',
            'password' => 'required|min:6|confirmed',
        ], [
            'nik.digits'    => 'NIK harus 16 digit angka.',
            'nik.unique'    => 'NIK sudah terdaftar.',
            'email.unique'  => 'Email sudah digunakan.',
            'password.confirmed' => 'Konfirmasi password tidak cocok.',
        ]);

        User::create([
            'name'     => $request->nama,
            'nik'      => $request->nik,
            'email'    => $request->email,
            'password' => Hash::make($request->password),
            'status'   => 'pending', // tunggu approval admin
        ]);

        return redirect()->route('welcome')
            ->with('modal_pending', true); // trigger modal di welcome
    }

    // ── LOGIN ──
    public function login(Request $request)
    {
        $request->validate([
            'nik'      => 'required|digits:16',
            'password' => 'required',
        ]);

        $user = User::where('nik', $request->nik)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return back()->withErrors(['nik' => 'NIK atau password salah.'])->withInput();
        }

        if ($user->status === 'pending') {
            return back()->withErrors(['nik' => 'Akun kamu masih menunggu persetujuan admin.'])->withInput();
        }

        if ($user->status === 'banned') {
            return back()->withErrors(['nik' => 'Akun kamu telah dinonaktifkan.'])->withInput();
        }

        Auth::login($user, $request->boolean('remember'));

        return redirect()->intended('/dashboard');
    }

    // ── LOGOUT ──
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('welcome');
    }
}