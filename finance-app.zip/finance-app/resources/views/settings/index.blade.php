@extends('layouts.app')
@section('title','Pengaturan')

@section('content')
<style>
  :root {
    --forest: #111827;
    --surface: #f5faf6;
    --card: #ffffff;
    --border: #dae8d9;
    --border-strong: #c4dcc9;
    --text-1: #0d1f14;
    --text-2: #4f7060;
    --text-3: #8ba593;
    --accent: #111827;
    --accent-hover: #1f2937;
    --accent-text: #ffffff;
    --shadow-sm: 0 1px 6px rgba(13,31,20,0.06);
    --shadow-md: 0 6px 18px rgba(13,31,20,0.08);
    --radius: 14px;
    --font-ser: 'Instrument Serif', serif;
    --font-sans: 'DM Sans', sans-serif;
  }

  [data-theme="dark"] {
    --surface: #0b1c13;
    --card: #122918;
    --border: #1f3f2d;
    --border-strong: #29503a;
    --text-1: #f4fbf5;
    --text-2: #97d5a0;
    --text-3: #658f72;
    --accent: #4ade80;
    --accent-hover: #16a34a;
    --accent-text: #0f2218;
    --shadow-sm: 0 1px 6px rgba(0,0,0,0.2);
    --shadow-md: 0 6px 18px rgba(0,0,0,0.35);
  }

  *, *::before, *::after { box-sizing: border-box; }
  body { margin: 0; font-family: var(--font-sans); background: var(--surface); color: var(--text-1); }
  .topbar { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:18px; margin-bottom:24px; }
  .page-title { margin:0; font-family: var(--font-ser); font-size:2.1rem; font-weight:400; letter-spacing:-0.3px; }
  .page-subtitle { margin-top:8px; color:var(--text-3); font-size:14px; line-height:1.7; }
  .topbar-actions { display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
  #themeToggle { width:44px; height:44px; border-radius:8px; border:1px solid var(--border); background:var(--card); color:var(--text-1); display:grid; place-items:center; cursor:pointer; transition:transform .2s ease; }
  #themeToggle:hover { transform: translateY(-1px); }
  .avatar {
    width:44px;
    height:44px;
    border-radius:8px;
    background: var(--forest);
    color: var(--accent);
    display:grid;
    place-items:center;
    font-weight:700;
    font-size:1rem;
  }

  [data-theme="dark"] .avatar {
    background: var(--forest-2);
    color: var(--accent-hover);
  }

  .panel { background:var(--card); border:1px solid var(--border); border-radius:var(--radius); padding:28px; box-shadow:var(--shadow-sm); max-width:740px; margin:0 auto; }
  .profile-header { display:flex; align-items:center; gap:18px; margin-bottom:24px; padding-bottom:22px; border-bottom:1px solid var(--border); }
  .profile-avatar { width:68px; height:68px; background:var(--accent); color:#fff; border-radius:8px; display:grid; place-items:center; font-weight:800; font-size:1.4rem; flex-shrink:0; }
  .profile-name { font-size:1.2rem; font-weight:700; color:var(--text-1); margin-bottom:4px; }
  .profile-email { font-size:.92rem; color:var(--text-2); }
  .card-title { font-size:1rem; font-weight:700; color:var(--text-1); margin:0 0 18px; }
  .form-row { display:grid; gap:10px; margin-bottom:18px; }
  .form-row label { font-size:.82rem; font-weight:700; color:var(--text-3); text-transform:uppercase; letter-spacing:.1px; }
  .form-input { width:100%; padding:14px 16px; border-radius:8px; border:1px solid var(--border); background:var(--surface); color:var(--text-1); font-size:.95rem; }
  .form-input:focus { outline:none; border-color:var(--accent); box-shadow:0 0 0 3px rgba(17,24,39,0.16); }
  .form-input[readonly] { opacity:.7; cursor:not-allowed; }
  .btn-save { display:inline-flex; align-items:center; justify-content:center; gap:8px; width:100%; padding:14px 18px; border:none; border-radius:8px; background:var(--accent); color:var(--accent-text); font-weight:700; cursor:pointer; transition:transform .2s ease, filter .2s ease; }
  .btn-save:hover { transform: translateY(-1px); filter:brightness(1.02); }
  .alert { padding:16px 18px; border-radius:8px; margin-bottom:22px; font-weight:600; }
  .alert.success { background: rgba(17,24,39,0.06); color: var(--text-1); border:1px solid rgba(17,24,39,0.12); }
  .error { margin-top:8px; color:#b91c1c; font-size:.88rem; }
  .profile-avatar img, .avatar img { width:100%; height:100%; object-fit:cover; border-radius:24px; }
</style>

<div class="topbar">
  <div>
    <h1 class="page-title">Pengaturan</h1>
    <div class="page-subtitle">Atur informasi akun dan preferensi aplikasi.</div>
  </div>
  <div class="topbar-actions">
    <button id="themeToggle" type="button" title="Ganti tema"></button>
    <div class="avatar">
      @if(auth()->user()->profile_photo_path)
        <img src="{{ asset(auth()->user()->profile_photo_path) }}" alt="Avatar">
      @else
        {{ strtoupper(substr(auth()->user()->name,0,1)) }}
      @endif
    </div>
  </div>
</div>

<div class="panel">
  <form action="{{ route('settings.update') }}" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="profile-header">
      <div class="profile-avatar">
        @if(auth()->user()->profile_photo_path)
          <img src="{{ url(auth()->user()->profile_photo_path) }}" alt="Foto Profil" style="width:100%; height:100%; object-fit:cover; display:block;">
        @else
          {{ strtoupper(substr(auth()->user()->name,0,1)) }}
        @endif
      </div>
      <div>
        <div class="profile-name">{{ auth()->user()->name }}</div>
        <div class="profile-email">{{ auth()->user()->email }}</div>
      </div>
    </div>

    @if(session('success'))
      <div class="alert success">{{ session('success') }}</div>
    @endif

    <div class="card-title">Profil Pengguna</div>

    <div class="form-row">
      <label for="name">Nama</label>
      <input id="name" type="text" name="name" class="form-input" value="{{ old('name', auth()->user()->name) }}" required>
      @error('name') <div class="error">{{ $message }}</div> @enderror
    </div>

    <div class="form-row">
      <label>Email</label>
      <input type="email" class="form-input" value="{{ auth()->user()->email }}" readonly>
    </div>

    <div class="form-row">
      <label for="profile_photo">Foto Profil</label>
      <input id="profile_photo" type="file" name="profile_photo" class="form-input" accept="image/*">
      @error('profile_photo') <div class="error">{{ $message }}</div> @enderror
    </div>

    <button type="submit" class="btn-save">Simpan Perubahan</button>
  </form>
</div>
@endsection
