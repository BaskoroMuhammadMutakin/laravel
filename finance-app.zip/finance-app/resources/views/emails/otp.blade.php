<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Kode OTP Reset Password</title>
</head>
<body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #2563eb;">Reset Password - Kode OTP</h2>

        <p>Halo,</p>

        <p>Anda telah meminta untuk mereset password akun Anda. Berikut adalah kode OTP (One-Time Password) yang dapat Anda gunakan:</p>

        <div style="background-color: #f8fafc; border: 2px solid #e2e8f0; border-radius: 8px; padding: 20px; text-align: center; margin: 20px 0;">
            <h1 style="color: #1f2937; font-size: 32px; margin: 0; letter-spacing: 4px;">{{ $otp }}</h1>
        </div>

        <p><strong>Penting:</strong></p>
        <ul>
            <li>Kode OTP ini berlaku selama 10 menit</li>
            <li>Jangan bagikan kode ini kepada siapapun</li>
            <li>Jika Anda tidak meminta reset password, abaikan email ini</li>
        </ul>

        <p>Jika Anda mengalami kesulitan, silakan hubungi tim support kami.</p>

        <p>Terima kasih,<br>
        Tim Finance App</p>
    </div>
</body>
</html>