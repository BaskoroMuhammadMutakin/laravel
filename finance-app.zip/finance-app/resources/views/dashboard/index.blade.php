@extends('layouts.app')
@section('title','Dashboard')

@section('content')
<style>
  :root {
    --forest:      #111827;
    --forest-2:    #1f2937;
    --forest-3:    #374151;
    --balance-bg:  #111827;
    --balance-overlay: rgba(17,24,39,0.08);
    --accent:      #111827;
    --accent-hover:#1f2937;
    --accent-text: #ffffff;
    --green:       #2ecc71;
    --green-dim:   #7ee8a2;
    --surface:     #f5faf6;
    --card:        #ffffff;
    --border:      #e0ede4;
    --border-2:    #c8dece;
    --text-1:      #0d1f14;
    --text-2:      #4a6b55;
    --text-3:      #9eb8a5;
    --income:      #166534;
    --expense:     #991b1b;
    --shadow-sm:   0 1px 4px rgba(13,31,20,0.06);
    --shadow-md:   0 4px 16px rgba(13,31,20,0.08);
    --font-ser:    'Instrument Serif', serif;
    --font-sans:   'DM Sans', sans-serif;
    --radius:      14px;
    --radius-sm:   10px;
  }

  [data-theme="dark"] {
    --forest:      #f0faf3;
    --forest-2:    #e0f2e9;
    --forest-3:    #c3e6cc;
    --balance-bg:  #0f2218;
    --balance-overlay: rgba(74,222,128,0.12);
    --accent:      #4ade80;
    --accent-hover:#16a34a;
    --accent-text: #0f2218;
    --surface:     #0a1610;
    --card:        #0f2218;
    --border:      #1a3523;
    --border-2:    #264d32;
    --text-1:      #f0faf3;
    --text-2:      #7ee8a2;
    --text-3:      #4a6b55;
    --income:      #4ade80;
    --expense:     #f87171;
    --shadow-sm:   0 1px 4px rgba(0,0,0,0.3);
    --shadow-md:   0 4px 16px rgba(0,0,0,0.4);
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: var(--font-sans);
    background: var(--surface);
    color: var(--text-1);
    transition: background 0.3s, color 0.3s;
  }

  /* ── TOPBAR ── */
  .topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 14px 22px;
    margin-bottom: 20px;
    box-shadow: var(--shadow-sm);
  }

  .topbar-brand { display: flex; flex-direction: column; gap: 2px; }

  .topbar-brand h1 {
    font-family: var(--font-ser);
    font-size: 1.35rem;
    font-weight: 400;
    color: var(--text-1);
    line-height: 1;
  }

  .topbar-brand p {
    font-size: 12px;
    color: var(--text-3);
    font-weight: 300;
  }

  .topbar-right { display: flex; align-items: center; gap: 10px; }

  .theme-btn {
    width: 36px; height: 36px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
    background: var(--surface);
    color: var(--text-2);
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: background 0.2s, border-color 0.2s;
  }
  .theme-btn:hover { background: var(--border); }

  .avatar {
    width: 36px; height: 36px;
    background: var(--forest);
    color: var(--accent);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-weight: 500;
    font-size: 13px;
    font-family: var(--font-sans);
    overflow: hidden;
    flex-shrink: 0;
  }

  [data-theme="dark"] .avatar {
    background: var(--forest-2);
    color: var(--accent-hover);
  }

  .avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }

  /* ── BALANCE CARD ── */
  .balance-card {
    background: var(--balance-bg);
    border-radius: 18px;
    padding: 28px 32px;
    margin-bottom: 20px;
    position: relative;
    overflow: hidden;
    transition: background 0.3s ease, border-color 0.3s ease;
  }

  .balance-card::before {
    content: '';
    position: absolute;
    top: -50px; right: -50px;
    width: 220px; height: 220px;
    border-radius: 50%;
    background: radial-gradient(circle, var(--balance-overlay) 0%, transparent 70%);
    pointer-events: none;
  }

  .balance-card::after {
    content: '';
    position: absolute;
    bottom: -40px; left: 40%;
    width: 160px; height: 160px;
    border-radius: 50%;
    background: radial-gradient(circle, var(--balance-overlay) 0%, transparent 70%);
    pointer-events: none;
  }

  .balance-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20px;
  }

  .balance-label {
    font-size: 11px;
    font-weight: 500;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: rgba(255,255,255,0.65);
    margin-bottom: 8px;
  }

  .balance-amount {
    font-family: var(--font-ser);
    font-size: 2.8rem;
    color: #f0faf3;
    line-height: 1;
    font-weight: 400;
  }

  .balance-meta {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 14px;
  }

  .balance-dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--accent);
  }

  .balance-meta-text {
    font-size: 12px;
    color: rgba(255,255,255,0.65);
  }

  .balance-month-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.18);
    color: var(--card);
    font-size: 11.5px;
    font-weight: 500;
    padding: 4px 12px;
    border-radius: 99px;
    margin-top: 18px;
  }

  .balance-bar-track {
    height: 3px;
    border-radius: 99px;
    background: rgba(255,255,255,0.08);
    overflow: hidden;
    margin-top: 22px;
  }

  .balance-bar-fill {
    height: 100%;
    border-radius: 99px;
    background: var(--accent);
    width: 0%;
    transition: width 1.2s cubic-bezier(.4,0,.2,1);
  }

  /* ── STATS GRID ── */
  .stats-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
    margin-bottom: 20px;
  }

  @media (max-width: 580px) { .stats-grid { grid-template-columns: 1fr; } }

  .stats-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 20px 22px;
    box-shadow: var(--shadow-sm);
    transition: background 0.3s, border-color 0.3s;
  }

  .stats-label {
    font-size: 10.5px;
    font-weight: 500;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: var(--text-3);
    margin-bottom: 8px;
  }

  .stats-value {
    font-family: var(--font-ser);
    font-size: 1.9rem;
    color: var(--text-1);
    line-height: 1;
    font-weight: 400;
  }

  .stats-sub {
    font-size: 12px;
    color: var(--text-3);
    margin-top: 6px;
    font-weight: 300;
  }

  .stats-indicator {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 11px;
    font-weight: 500;
    margin-top: 10px;
    padding: 3px 8px;
    border-radius: 99px;
  }

  .stats-indicator.income {
    background: #eaf7ef;
    color: #166534;
  }

  .stats-indicator.expense {
    background: #fef2f2;
    color: #991b1b;
  }

  [data-theme="dark"] .stats-indicator.income {
    background: rgba(74,222,128,0.12);
    color: #4ade80;
  }

  [data-theme="dark"] .stats-indicator.expense {
    background: rgba(248,113,113,0.12);
    color: #f87171;
  }

  /* ── PANEL ── */
  .panel {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow-md);
    overflow: hidden;
    transition: background 0.3s, border-color 0.3s;
  }

  .panel-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 18px 22px;
    border-bottom: 1px solid var(--border);
  }

  .panel-title {
    font-size: 13.5px;
    font-weight: 500;
    color: var(--text-1);
    letter-spacing: -0.2px;
  }

  .panel-count {
    font-size: 11px;
    color: var(--text-3);
    background: var(--surface);
    border: 1px solid var(--border);
    padding: 2px 10px;
    border-radius: 99px;
    font-weight: 400;
  }

  /* ── TABLE ── */
  .table-wrap { overflow-x: auto; }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
  }

  thead th {
    padding: 10px 20px;
    text-align: left;
    font-size: 10.5px;
    font-weight: 500;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--text-3);
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    white-space: nowrap;
  }

  [data-theme="dark"] thead th { background: rgba(255,255,255,0.02); }

  thead th:last-child { text-align: right; }

  tbody td {
    padding: 14px 20px;
    color: var(--text-1);
    border-bottom: 1px solid var(--border);
    vertical-align: middle;
    transition: background 0.15s;
  }

  tbody tr:last-child td { border-bottom: none; }
  tbody tr:hover td { background: var(--surface); }

  .td-date { color: var(--text-3); font-size: 12px; font-weight: 300; white-space: nowrap; }

  .td-category {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-weight: 500;
    font-size: 13px;
  }

  .cat-dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    flex-shrink: 0;
  }

  .td-desc { color: var(--text-2); font-weight: 300; }

  .td-amount {
    text-align: right;
    font-weight: 500;
    font-size: 13.5px;
    white-space: nowrap;
  }

  .td-amount.income { color: var(--income); }
  .td-amount.expense { color: var(--expense); }

  .empty-row td {
    text-align: center;
    padding: 52px 20px;
    color: var(--text-3);
    font-size: 13px;
    font-weight: 300;
  }

  .empty-icon {
    display: block;
    margin: 0 auto 10px;
    opacity: 0.3;
  }

  /* ── TRANSITIONS ── */
  .stats-card, .panel, .topbar { transition: background 0.3s, border-color 0.3s, box-shadow 0.3s; }
</style>

{{-- TOPBAR --}}
<div class="topbar">
  <div class="topbar-brand">
    <h1>KeuanganKu</h1>
    <p>Ringkasan keuangan dan aktivitas terbaru</p>
  </div>
  <div class="topbar-right">
    <button id="themeToggle" class="theme-btn" title="Ganti tema" type="button">
      <svg id="themeIcon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
      </svg>
    </button>
    <div class="avatar">
      @if(auth()->user()->profile_photo_path)
        <img src="{{ url(auth()->user()->profile_photo_path) }}" alt="Avatar">
      @else
        {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
      @endif
    </div>
  </div>
</div>

{{-- BALANCE CARD --}}
@php
  $income  = $monthlyIncome  ?? 0;
  $expense = $monthlyExpense ?? 0;
  $balance = $totalBalance   ?? 0;
  $barPct  = ($income + $expense) > 0 ? min(100, round($income / ($income + $expense) * 100)) : 0;
@endphp

<div class="balance-card">
  <div class="balance-top">
    <div>
      <div class="balance-label">Total Saldo</div>
      <div class="balance-amount">Rp {{ number_format($balance, 0, ',', '.') }}</div>
      <div class="balance-meta">
        <div class="balance-dot"></div>
        <span class="balance-meta-text">{{ now()->translatedFormat('F Y') }}</span>
      </div>
    </div>
    <div style="text-align:right;">
      <div class="balance-label" style="margin-bottom:6px;">Rasio</div>
      <div style="font-family:var(--font-ser);font-size:1.6rem;color:#f0faf3;line-height:1;">{{ $barPct }}%</div>
      <div style="font-size:11px;color:rgba(255,255,255,0.35);margin-top:2px;">pemasukan</div>
    </div>
  </div>
  <div class="balance-bar-track">
    <div class="balance-bar-fill" id="balanceBar" style="width:0%"></div>
  </div>
</div>

{{-- STATS --}}
<div class="stats-grid">
  <div class="stats-card">
    <div class="stats-label">Pemasukan Bulan Ini</div>
    <div class="stats-value">Rp {{ number_format($income, 0, ',', '.') }}</div>
    <div class="stats-sub">Total pemasukan bulan berjalan</div>
    <div class="stats-indicator income">
      <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
        <path d="M5 8V2M2 5l3-3 3 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      Masuk
    </div>
  </div>
  <div class="stats-card">
    <div class="stats-label">Pengeluaran Bulan Ini</div>
    <div class="stats-value">Rp {{ number_format($expense, 0, ',', '.') }}</div>
    <div class="stats-sub">Total pengeluaran bulan berjalan</div>
    <div class="stats-indicator expense">
      <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
        <path d="M5 2v6M8 5L5 8 2 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      Keluar
    </div>
  </div>
</div>

{{-- TRANSACTIONS --}}
<div class="panel">
  <div class="panel-head">
    <span class="panel-title">Transaksi Terakhir</span>
    <span class="panel-count">{{ $transactions->count() }} transaksi</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Tanggal</th>
          <th>Kategori</th>
          <th>Deskripsi</th>
          <th style="text-align:right;">Jumlah</th>
        </tr>
      </thead>
      <tbody>
        @forelse($transactions as $trx)
          @php $isIncome = $trx->category->type === 'income'; @endphp
          <tr>
            <td class="td-date">{{ $trx->transaction_date->format('d M Y') }}</td>
            <td>
              <span class="td-category">
                <span class="cat-dot" style="background: {{ $isIncome ? 'var(--accent)' : '#ef4444' }}"></span>
                {{ $trx->category->name }}
              </span>
            </td>
            <td class="td-desc">{{ $trx->description ?: '—' }}</td>
            <td class="td-amount {{ $isIncome ? 'income' : 'expense' }}">
              {{ $isIncome ? '+' : '−' }}Rp {{ number_format($trx->amount, 0, ',', '.') }}
            </td>
          </tr>
        @empty
          <tr class="empty-row">
            <td colspan="4">
              <svg class="empty-icon" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
                <rect x="2" y="5" width="20" height="14" rx="3"/>
                <path d="M2 10h20"/>
              </svg>
              Belum ada transaksi
            </td>
          </tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>

<script>
  setTimeout(() => {
    const bar = document.getElementById('balanceBar');
    if (bar) bar.style.width = '{{ $barPct }}%';
  }, 300);
</script>
@endsection
