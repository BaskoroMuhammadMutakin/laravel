<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>@yield('title')</title>
<link rel="icon" type="image/svg+xml" href="{{ asset('images/money-curreny-svgrepo-com (1).svg') }}">
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,700&display=swap" rel="stylesheet">
<style>
:root {
  color-scheme: light;
  --forest: #111827;
  --forest-2: #1f2937;
  --forest-3: #374151;
  --accent: #111827;
  --accent-hover: #1f2937;
  --accent-text: #ffffff;
  --green: #2ecc71;
  --green-dim: #7ee8a2;
  --surface: #f5faf6;
  --card: #ffffff;
  --border: #e0ede4;
  --border-2: #c8dece;
  --text-1: #0d1f14;
  --text-2: #4a6b55;
  --text-3: #9eb8a5;
  --income: #166534;
  --expense: #991b1b;
  --shadow-sm: 0 1px 4px rgba(13,31,20,0.06);
  --shadow-md: 0 4px 16px rgba(13,31,20,0.08);
  --font-ser: 'Instrument Serif', serif;
  --font-sans: 'DM Sans', sans-serif;
  --radius: 14px;
  --radius-sm: 10px;
}

html[data-theme="dark"] {
  --forest: #f0faf3;
  --forest-2: #e0f2e9;
  --forest-3: #c3e6cc;
  --accent: #4ade80;
  --accent-hover: #16a34a;
  --accent-text: #0f2218;
  --surface: #0a1610;
  --card: #0f2218;
  --border: #1a3523;
  --border-2: #264d32;
  --text-1: #f0faf3;
  --text-2: #7ee8a2;
  --text-3: #4a6b55;
  --income: #4ade80;
  --expense: #f87171;
  --shadow-sm: 0 1px 4px rgba(0,0,0,0.3);
  --shadow-md: 0 4px 16px rgba(0,0,0,0.4);
}

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  min-height: 100%;
}

body {
  min-height: 100vh;
  font-family: var(--font-sans);
  background: var(--surface);
  color: var(--text-1);
}

a {
  color: inherit;
  text-decoration: none;
}

.container {
  display: flex;
  min-height: 100vh;
}

.sidebar {
  width: 280px;
  background: var(--card);
  border-right: 1px solid var(--border);
  padding: 28px 22px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.sidebar h2 {
  margin: 0 0 24px;
  font-family: var(--font-ser);
  font-size: 1.15rem;
  font-weight: 400;
  color: var(--text-1);
}

.sidebar nav {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.sidebar a {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border-radius: var(--radius-sm);
  color: var(--text-2);
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 400;
  transition: background 0.2s ease, color 0.2s ease;
}

.sidebar a:hover {
  background: var(--surface);
}

.sidebar a.active {
  background: var(--accent);
  color: var(--accent-text);
}

html[data-theme="dark"] .sidebar a.active {
  background: var(--forest-2);
  color: var(--accent-text);
}

.sidebar-footer {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.logout-card {
  width: 100%;
}

.logout-card form {
  width: 100%;
}

.logout-card button {
  width: 100%;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-2);
  padding: 10px 16px;
  border-radius: var(--radius-sm);
  font-family: var(--font-sans);
  font-size: 13px;
  font-weight: 500;
  text-align: left;
  cursor: pointer;
  transition: background 0.2s ease, color 0.2s ease;
}

.logout-card button:hover {
  color: var(--expense);
  background: rgba(153,27,27,0.08);
}

.content {
  flex: 1;
  padding: 30px;
}

.topbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 14px;
  margin-bottom: 24px;
}

.page-title {
  margin: 0;
  font-family: var(--font-ser);
  font-size: 2rem;
  font-weight: 400;
  color: var(--text-1);
}

.page-subtitle {
  margin-top: 8px;
  color: var(--text-3);
  font-size: 13px;
  line-height: 1.6;
}

.topbar-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.button,
.button-small,
.button-secondary {
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s ease;
  font-family: var(--font-sans);
}

.button {
  border: none;
  background: var(--accent);
  color: var(--accent-text);
  padding: 10px 18px;
  font-size: 13px;
  font-weight: 500;
}

.button:hover {
  filter: brightness(1.08);
}

.button-small {
  border: none;
  background: var(--accent);
  color: var(--accent-text);
  padding: 10px 14px;
  font-size: 13px;
  font-weight: 500;
}

.button-secondary {
  background: transparent;
  border: 1px solid var(--border-2);
  color: var(--text-2);
  padding: 10px 18px;
  font-size: 13px;
  font-weight: 500;
}

.button-secondary:hover {
  background: var(--surface);
}

#themeToggle {
  width: 44px;
  height: 44px;
  min-width: 44px;
  border-radius: var(--radius-sm);
  border: 1px solid var(--border);
  background: var(--card);
  color: var(--text-1);
  display: grid;
  place-items: center;
  cursor: pointer;
  transition: background 0.2s ease, transform 0.2s ease;
}

#themeToggle:hover {
  transform: translateY(-1px);
}

#themeToggle svg {
  display: block;
}

.section-actions {
  display: flex;
  justify-content: flex-start;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 22px;
}

.card,
.panel {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 14px;
  box-shadow: var(--shadow-sm);
  padding: 24px;
  margin-bottom: 22px;
}

.card-title {
  font-size: 1rem;
  font-weight: 700;
  color: var(--text-1);
  margin-bottom: 18px;
}

.input-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 18px;
}

.input-group label {
  color: var(--text-3);
  font-size: 10.5px;
  font-weight: 500;
  letter-spacing: 1.5px;
  text-transform: uppercase;
}

.input-group input,
.input-group select,
.input-group textarea {
  width: 100%;
  padding: 10px 14px;
  border: 1px solid var(--border);
  border-radius: 10px;
  background: var(--card);
  color: var(--text-1);
  font-size: 13px;
  outline: none;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.input-group input:focus,
.input-group select:focus,
.input-group textarea:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 4px rgba(17,24,39,0.15);
}

.select-wrapper {
  position: relative;
}

.select-wrapper::after {
  content: '▾';
  position: absolute;
  right: 14px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--text-3);
  pointer-events: none;
  font-size: 12px;
}

.table-simple {
  width: 100%;
  border-collapse: collapse;
}

.table-simple th {
  text-align: left;
  padding: 14px 20px;
  font-size: 10.5px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 1px;
  color: var(--text-3);
  background: var(--surface);
  border-bottom: 1px solid var(--border);
}

.table-simple td {
  padding: 14px 20px;
  font-size: 13px;
  color: var(--text-2);
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}

.table-simple tbody tr:hover td {
  background: var(--surface);
}

.badge {
  display: inline-flex;
  align-items: center;
  border-radius: 99px;
  padding: 3px 10px;
  font-size: 11px;
  font-weight: 600;
}

.badge-income {
  background: #eaf7ef;
  color: #166534;
}

.badge-expense {
  background: #fef2f2;
  color: #991b1b;
}

.status-chip.income { background: #eaf7ef; color: #166534; }
.status-chip.expense { background: #fef2f2; color: #991b1b; }

.empty-state {
  text-align: center;
  color: var(--text-3);
  font-size: 13px;
  padding: 32px 16px;
}

.empty-state svg {
  display: block;
  margin: 0 auto 12px;
  color: var(--text-3);
}

.button-icon {
  width: 34px;
  height: 34px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text-2);
  border-radius: var(--radius-sm);
  cursor: pointer;
  transition: background 0.2s ease, border-color 0.2s ease, color 0.2s ease;
}

.button-icon:hover {
  background: var(--surface);
}

.button-icon.danger:hover {
  color: var(--expense);
  border-color: var(--expense);
}

.category-pill {
  display: inline-flex;
  align-items: center;
  gap: 10px;
}

.category-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--green);
}

.category-dot.expense { background: var(--expense); }

.amount-income {
  color: #166534;
  font-weight: 700;
  text-align: right;
}

.amount-expense {
  color: #991b1b;
  font-weight: 700;
  text-align: right;
}

@media(max-width:1024px) {
  .container { flex-direction: column; }
  .sidebar { width: 100%; }
}

</style>

</head>
<body>
<script>document.documentElement.setAttribute('data-theme', localStorage.getItem('kk_theme') || 'light')</script>

<div class="container">

  {{-- SIDEBAR --}}
  <div class="sidebar">
    <div>
      <h2>KeuanganKu</h2>

      <nav>
        <a href="{{ route('dashboard') }}" class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">
          <span class="icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5L12 3l9 6.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1V9.5z"></path></svg></span>
          Dashboard
        </a>
        <a href="{{ route('transactions.index') }}" class="{{ request()->routeIs('transactions.*') ? 'active' : '' }}">
          <span class="icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"></path><path d="M12 5l7 7-7 7"></path></svg></span>
          Transaksi
        </a>
        <a href="{{ route('reports.index') }}" class="{{ request()->routeIs('reports.*') ? 'active' : '' }}">
          <span class="icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19h16M9 19V9M15 19V5"></path></svg></span>
          Laporan
        </a>
        <a href="{{ route('settings.index') }}" class="{{ request()->routeIs('settings.*') ? 'active' : '' }}">
          <span class="icon"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15 1.65 1.65 0 0 0 3.09 14H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0 .33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6 1.65 1.65 0 0 0 10.51 3H11a2 2 0 0 1 4 0h.09A1.65 1.65 0 0 0 16 4.6 1.65 1.65 0 0 0 17.82 4.93l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9 1.65 1.65 0 0 0 20.91 10H21a2 2 0 0 1 0 4h-.09A1.65 1.65 0 0 0 19.4 15z"></path></svg></span>
          Pengaturan
        </a>
      </nav>
    </div>

    <div class="sidebar-footer">
      <div class="logout-card">
        <form action="{{ route('logout') }}" method="POST">
          @csrf
          <button type="submit">Logout</button>
        </form>
      </div>
    </div>
  </div>

  {{-- CONTENT --}}
  <div class="content">
    @yield('content')
  </div>

  </div>

  <script>
    (function() {
      const toggle = document.getElementById('themeToggle');
      const sunIcon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>';
      const moonIcon = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>';
      
      const setMode = (mode) => {
        document.documentElement.setAttribute('data-theme', mode);
        if (toggle) {
          toggle.innerHTML = mode === 'dark' ? sunIcon : moonIcon;
        }
        localStorage.setItem('kk_theme', mode);
      };

      const saved = localStorage.getItem('kk_theme');
      const defaultMode = saved || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
      setMode(defaultMode);

      if (toggle) {
        toggle.addEventListener('click', function() {
          const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
          setMode(next);
        });
      }
    })();
  </script>
</body>
</html>
