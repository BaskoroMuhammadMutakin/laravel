<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>KeuanganKu – @yield('title')</title>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --green-dark: #1f4037; --green-mid: #2d6a4f; --green-light: #1e8449;
      --green: #2ecc71; --navy: #1a2336; --font: 'Plus Jakarta Sans', sans-serif;
    }
    body {
      font-family: var(--font); min-height: 100vh;
      background: linear-gradient(135deg, #c8e6c9 0%, #b2dfdb 40%, #80cbc4 100%);
      display: flex; align-items: center; justify-content: center; padding: 30px;
    }
    .main-card {
      width: 100%; max-width: 1200px; background: #fff;
      border-radius: 30px; overflow: hidden;
      box-shadow: 0 50px 120px rgba(30,50,80,0.25);
    }
    .hero {
      background: linear-gradient(135deg, var(--green-dark), var(--green-mid), var(--green-light));
      padding: 50px; text-align: center;
    }
    .hero h1 { color: #fff; font-size: 2.2rem; font-weight: 800; }
    .hero p  { color: rgba(255,255,255,0.8); font-size: 0.95rem; margin-top: 4px; }
    .content { display: flex; }
    .left  { flex: 1; padding: 40px; }
    .right { flex: 1; padding: 40px; border-left: 1px solid #e4eaf2; }
    .btn {
      display: flex; align-items: center; gap: 10px; width: 100%;
      padding: 14px 18px; border-radius: 12px; font-size: 0.9rem; font-weight: 600;
      text-decoration: none; margin-bottom: 10px; transition: 0.2s; border: none;
      cursor: pointer; font-family: var(--font);
      background: linear-gradient(135deg, var(--green-dark), var(--green-mid));
      color: #fff;
    }
    .btn:hover { transform: translateY(-2px); opacity: 0.9; }
    .btn-outline { background: #f0f4f8; color: var(--navy); }
    .btn-outline:hover { background: #e4eaf2; transform: translateY(-2px); opacity: 1; }
    .btn-green { background: var(--green); }
    .btn-green:hover { background: #27ae60; }
    .divider-label {
      font-size: 0.72rem; font-weight: 700; color: #9ca3af;
      text-transform: uppercase; letter-spacing: 0.8px; margin: 16px 0 10px;
    }
    .form-group { margin-bottom: 14px; }
    .form-label { display: block; font-size: 0.8rem; font-weight: 700; color: var(--navy); margin-bottom: 6px; }
    .form-input {
      width: 100%; padding: 13px 14px; border-radius: 12px;
      border: 1.5px solid #e4eaf2; font-family: var(--font);
      font-size: 0.88rem; color: var(--navy); outline: none; background: #f9fbfd; transition: 0.2s;
    }
    .form-input:focus { border-color: var(--green); background: #fff; box-shadow: 0 0 0 3px rgba(46,204,113,0.12); }
    .form-input.is-invalid { border-color: #e74c3c; }
    .invalid-feedback { color: #e74c3c; font-size: 0.78rem; margin-top: 4px; }
    .form-row { display: flex; gap: 10px; }
    .form-row .form-group { flex: 1; }
    .back-link {
      display: inline-flex; align-items: center; gap: 6px;
      font-size: 0.8rem; font-weight: 600; color: #9ca3af;
      text-decoration: none; margin-bottom: 20px;
    }
    .back-link:hover { color: var(--navy); }
    .page-title { font-size: 1.2rem; font-weight: 800; color: var(--navy); margin-bottom: 4px; }
    .page-sub   { font-size: 0.82rem; color: #9ca3af; margin-bottom: 20px; }
    .alert { padding: 13px 16px; border-radius: 12px; font-size: 0.85rem; font-weight: 600; margin-bottom: 14px; }
    .alert-error   { background: #fdecea; color: #c0392b; border: 1px solid #f5c6cb; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .info-item { display: flex; gap: 14px; margin-bottom: 22px; align-items: flex-start; }
    .info-icon {
      width: 44px; height: 44px; border-radius: 12px;
      background: rgba(46,204,113,0.1); display: flex; align-items: center;
      justify-content: center; flex-shrink: 0;
    }
    .info-icon svg { width: 22px; height: 22px; }
    .info-title { font-size: 0.88rem; font-weight: 700; color: var(--navy); margin-bottom: 3px; }
    .info-text  { font-size: 0.82rem; color: #6b7280; line-height: 1.6; }
    .section-title { font-size: 1rem; font-weight: 800; color: var(--navy); margin-bottom: 16px; }

    /* Modal */
    .modal-overlay {
      position: fixed; inset: 0; background: rgba(20,40,30,0.55);
      backdrop-filter: blur(4px); display: flex; align-items: center;
      justify-content: center; z-index: 999;
    }
    .modal-box {
      background: #fff; border-radius: 22px; padding: 36px 32px;
      max-width: 380px; width: 90%; text-align: center;
      box-shadow: 0 30px 80px rgba(0,0,0,0.2);
    }
    .modal-icon { font-size: 2.5rem; margin-bottom: 14px; }
    .modal-title { font-size: 1.15rem; font-weight: 800; color: var(--navy); margin-bottom: 8px; }
    .modal-text { font-size: 0.85rem; color: #6b7280; line-height: 1.6; margin-bottom: 20px; }
    .progress-wrap { width: 100%; background: #f0f4f8; border-radius: 99px; height: 6px; overflow: hidden; }
    .progress-bar  { height: 100%; background: var(--green); border-radius: 99px; width: 0%; transition: width 3s linear; }
  </style>
  @stack('styles')
</head>
<body>

@if(session('modal_pending'))
<div class="modal-overlay" id="modalOverlay">
  <div class="modal-box">
    <div class="modal-icon">⏳</div>
    <div class="modal-title">Menunggu Persetujuan</div>
    <div class="modal-text">
      Pendaftaran berhasil dikirim.<br>
      Akun sedang ditinjau oleh admin.<br>
      Kamu akan diarahkan kembali ke halaman utama.
    </div>
    <div class="progress-wrap">
      <div class="progress-bar" id="modalProgress"></div>
    </div>
  </div>
</div>
<script>
  setTimeout(() => document.getElementById('modalProgress').style.width = '100%', 50);
  setTimeout(() => document.getElementById('modalOverlay').remove(), 3300);
</script>
@endif

<div class="main-card">
  <div class="hero">
    <h1>KeuanganKu</h1>
    <p>Kelola keuangan dengan mudah &amp; rapi</p>
  </div>

  <div class="content">
    <div class="left">
      @yield('left')
    </div>
    <div class="right">
      <div class="section-title">Kenapa KeuanganKu?</div>
      <div class="info-item">
        <div class="info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="#27ae60" stroke-width="2"><path d="M12 1v22M5 6h14M5 12h14M5 18h14"/></svg></div>
        <div><div class="info-title">Catat Transaksi</div><div class="info-text">Catat pemasukan dan pengeluaran dengan lebih terstruktur.</div></div>
      </div>
      <div class="info-item">
        <div class="info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="#27ae60" stroke-width="2"><path d="M4 20V10M10 20V4M16 20v-6M22 20v-8"/></svg></div>
        <div><div class="info-title">Pantau Keuangan</div><div class="info-text">Lihat laporan bulanan agar tidak boncos di akhir bulan.</div></div>
      </div>
      <div class="info-item">
        <div class="info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="#27ae60" stroke-width="2"><path d="M13 2L3 14h7v8l10-12h-7z"/></svg></div>
        <div><div class="info-title">Akses Cepat</div><div class="info-text">Navigasi fitur penting dengan cepat dan efisien.</div></div>
      </div>
      <div class="info-item">
        <div class="info-icon"><svg viewBox="0 0 24 24" fill="none" stroke="#27ae60" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg></div>
        <div><div class="info-title">Aman & Terpercaya</div><div class="info-text">Data aman dengan sistem persetujuan admin sebelum masuk.</div></div>
      </div>
    </div>
  </div>
</div>

@stack('scripts')
</body>
</html>