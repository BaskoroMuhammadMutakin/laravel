@extends('layouts.app')
@section('title','Transaksi')

@section('content')
<style>
  .finance-page { display:grid; gap:22px; }
  .finance-hero {
    border:1px solid rgba(13,31,20,.08);
    border-radius:14px;
    background:
      linear-gradient(135deg, rgba(17,24,39,.96), rgba(35,70,61,.94)),
      radial-gradient(circle at 78% 18%, rgba(126,232,162,.24), transparent 35%);
    color:#fff;
    padding:26px;
    box-shadow:0 18px 42px rgba(13,31,20,.13);
    overflow:hidden;
  }
  html[data-theme="dark"] .finance-hero {
    background:
      linear-gradient(135deg, rgba(15,34,24,.98), rgba(8,18,13,.96)),
      radial-gradient(circle at 78% 18%, rgba(74,222,128,.16), transparent 35%);
    border-color:rgba(126,232,162,.14);
  }
  .hero-row { display:flex; justify-content:space-between; gap:20px; align-items:flex-start; flex-wrap:wrap; }
  .hero-kicker { color:rgba(255,255,255,.64); font-size:11px; font-weight:700; letter-spacing:1.4px; text-transform:uppercase; }
  .hero-title { margin:8px 0 0; font-family:var(--font-ser); font-size:clamp(2rem,4vw,3.35rem); font-weight:400; line-height:.98; }
  .hero-copy { max-width:560px; margin-top:12px; color:rgba(255,255,255,.72); font-size:14px; line-height:1.7; }
  .hero-balance { min-width:230px; text-align:right; }
  .hero-balance span { display:block; color:rgba(255,255,255,.6); font-size:12px; margin-bottom:7px; }
  .hero-balance strong { display:block; font-size:clamp(1.35rem,3vw,2.1rem); }
  .summary-grid { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:12px; margin-top:24px; }
  .summary-card { min-height:88px; border:1px solid rgba(255,255,255,.13); border-radius:12px; background:rgba(255,255,255,.08); padding:16px; }
  .summary-card span { display:block; margin-bottom:9px; color:rgba(255,255,255,.58); font-size:11px; font-weight:700; letter-spacing:1px; text-transform:uppercase; }
  .summary-card strong { color:#fff; font-size:1.15rem; }
  .notice { padding:14px 16px; border-radius:12px; font-size:13px; font-weight:700; }
  .notice.success { background:rgba(22,101,52,.1); border:1px solid rgba(22,101,52,.18); color:var(--income); }
  .notice.error { background:rgba(153,27,27,.08); border:1px solid rgba(153,27,27,.18); color:var(--expense); }
  .inline-alert {
    display:none; margin:-4px 0 16px; padding:12px 14px; border-radius:12px;
    background:rgba(245,158,11,.1); border:1px solid rgba(245,158,11,.22); color:#92400e;
    font-size:13px; font-weight:700; line-height:1.5;
  }
  html[data-theme="dark"] .inline-alert { color:#fbbf24; background:rgba(245,158,11,.08); }
  .work-grid { display:grid; grid-template-columns:minmax(330px,.86fr) minmax(460px,1.4fr); gap:22px; align-items:start; }
  .panel { background:var(--card); border:1px solid var(--border); border-radius:14px; box-shadow:var(--shadow-sm); overflow:hidden; margin:0; padding:0; }
  .panel-head { display:flex; justify-content:space-between; gap:14px; align-items:flex-start; padding:20px 22px; border-bottom:1px solid var(--border); }
  .panel-title { margin:0; color:var(--text-1); font-size:1rem; font-weight:700; }
  .panel-note { margin-top:5px; color:var(--text-3); font-size:12px; line-height:1.5; }
  .panel-body { padding:22px; }
  .field { display:grid; gap:8px; margin-bottom:16px; }
  .field label { color:var(--text-3); font-size:10.5px; font-weight:700; letter-spacing:1.2px; text-transform:uppercase; }
  .field input, .field select, .field textarea {
    width:100%; min-height:44px; border:1px solid var(--border); border-radius:10px;
    background:var(--surface); color:var(--text-1); font-family:var(--font-sans); font-size:13px;
    padding:11px 13px; outline:none; transition:border-color .18s, box-shadow .18s, background .18s;
  }
  .field textarea { min-height:84px; resize:vertical; line-height:1.6; }
  .field input:focus, .field select:focus, .field textarea:focus {
    background:var(--card); border-color:var(--accent); box-shadow:0 0 0 4px rgba(17,24,39,.12);
  }
  html[data-theme="dark"] .field input:focus,
  html[data-theme="dark"] .field select:focus,
  html[data-theme="dark"] .field textarea:focus { box-shadow:0 0 0 4px rgba(74,222,128,.14); }
  .form-row { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
  .amount-wrap { position:relative; }
  .amount-wrap span { position:absolute; left:13px; top:50%; transform:translateY(-50%); color:var(--text-3); font-size:12px; font-weight:700; }
  .amount-wrap input { padding-left:42px; }
  .primary-btn, .soft-btn {
    display:inline-flex; align-items:center; justify-content:center; min-height:44px; border-radius:10px;
    border:1px solid transparent; font-family:var(--font-sans); font-size:13px; font-weight:700; cursor:pointer; text-decoration:none;
  }
  .primary-btn { width:100%; background:var(--accent); color:var(--accent-text); padding:0 16px; }
  .soft-btn { background:var(--surface); border-color:var(--border); color:var(--text-2); padding:0 14px; }
  .delete-btn {
    display:inline-flex; align-items:center; justify-content:center; min-height:34px; border-radius:10px;
    border:1px solid rgba(153,27,27,.18); background:transparent; color:var(--expense);
    font-family:var(--font-sans); font-size:12px; font-weight:700; cursor:pointer; padding:0 12px;
  }
  .delete-btn:hover { background:rgba(153,27,27,.08); }
  .modal-backdrop {
    position:fixed; inset:0; z-index:100; display:none; align-items:center; justify-content:center;
    background:rgba(8,18,13,.46); backdrop-filter:blur(8px); padding:18px;
  }
  .modal-backdrop.is-open { display:flex; }
  .confirm-modal {
    width:min(420px,100%); background:var(--card); border:1px solid var(--border); border-radius:16px;
    box-shadow:0 24px 70px rgba(13,31,20,.25); overflow:hidden;
  }
  .confirm-head { padding:22px 22px 0; }
  .confirm-icon {
    width:42px; height:42px; border-radius:14px; display:grid; place-items:center;
    background:rgba(153,27,27,.1); color:var(--expense); margin-bottom:14px;
  }
  .confirm-title { margin:0; color:var(--text-1); font-size:1.05rem; font-weight:800; }
  .confirm-text { margin-top:8px; color:var(--text-3); font-size:13px; line-height:1.7; }
  .confirm-actions { display:flex; gap:10px; justify-content:flex-end; padding:20px 22px 22px; }
  .modal-cancel,
  .modal-danger {
    min-height:42px; border-radius:10px; padding:0 14px; font-family:var(--font-sans);
    font-size:13px; font-weight:800; cursor:pointer;
  }
  .modal-cancel { border:1px solid var(--border); background:var(--surface); color:var(--text-2); }
  .modal-danger { border:1px solid transparent; background:var(--expense); color:#fff; }
  .table-wrap { overflow-x:auto; }
  .transaction-table { width:100%; min-width:680px; border-collapse:collapse; }
  .transaction-table th { text-align:left; padding:13px 16px; color:var(--text-3); background:var(--surface); border-bottom:1px solid var(--border); font-size:10.5px; font-weight:800; letter-spacing:1px; text-transform:uppercase; }
  .transaction-table td { padding:16px; border-bottom:1px solid var(--border); color:var(--text-2); font-size:13px; vertical-align:middle; }
  .transaction-table tr:last-child td { border-bottom:0; }
  .transaction-table tbody tr:hover td { background:var(--surface); }
  .main-text { color:var(--text-1); font-weight:700; }
  .muted { color:var(--text-3); font-size:12px; margin-top:4px; }
  .pill { display:inline-flex; align-items:center; min-height:30px; padding:0 11px; border-radius:999px; font-size:12px; font-weight:800; }
  .pill.income { background:rgba(22,101,52,.1); color:var(--income); }
  .pill.expense { background:rgba(153,27,27,.09); color:var(--expense); }
  .amount { text-align:right; font-weight:800; }
  .amount.income { color:var(--income); }
  .amount.expense { color:var(--expense); }
  .empty-box { padding:34px 18px; text-align:center; color:var(--text-3); font-size:13px; line-height:1.7; }
  @media(max-width:1080px){ .work-grid,.summary-grid{grid-template-columns:1fr;} .hero-balance{text-align:left;} }
  @media(max-width:640px){ .content{padding:18px;} .finance-hero,.panel-head,.panel-body{padding:18px;} .form-row{grid-template-columns:1fr;} }
</style>

<div class="finance-page">
  <section class="finance-hero">
    <div class="hero-row">
      <div>
        <div class="hero-kicker">Transaksi</div>
        <h1 class="hero-title">Mencatat bagian keuangan dengan rapih dan struktur .</h1>
        <p class="hero-copy">silahkan tambahkan transaksi baru.</p>
      </div>
      <div class="hero-balance">
        <span>Saldo saat ini</span>
        <strong>Rp {{ number_format($totalBalance, 0, ',', '.') }}</strong>
      </div>
    </div>
    <div class="summary-grid">
      <div class="summary-card">
        <span>Pemasukan</span>
        <strong>Rp {{ number_format($incomeTotal, 0, ',', '.') }}</strong>
      </div>
      <div class="summary-card">
        <span>Pengeluaran</span>
        <strong>Rp {{ number_format($expenseTotal, 0, ',', '.') }}</strong>
      </div>
      <div class="summary-card">
        <span>Kategori di riwayat</span>
        <strong>{{ $categories->count() }} tersimpan</strong>
      </div>
    </div>
  </section>

  @if(session('success'))
    <div class="notice success">{{ session('success') }}</div>
  @endif
  @if($errors->any())
    <div class="notice error">{{ $errors->first() }}</div>
  @endif

  <div class="work-grid">
    <aside class="panel">
      <div class="panel-head">
        <div>
          <h2 class="panel-title">Tambah Transaksi</h2>
          <div class="panel-note">Satu panel untuk transaksi dan kategori baru.</div>
        </div>
        <button id="themeToggle" type="button" aria-label="Ganti tema"></button>
      </div>
      <div class="panel-body">
        <form method="POST" action="{{ route('transactions.store') }}" id="transactionForm">
          @csrf
          <div class="form-row">
            <div class="field">
              <label for="category_name">Kategori</label>
              <input id="category_name" type="text" name="category_name" value="{{ old('category_name') }}" placeholder="Contoh: makanan, gaji, transportasi" required>
            </div>
            <div class="field">
              <label for="category_type">Tipe</label>
              <select id="category_type" name="category_type" required>
                <option value="expense" {{ old('category_type') === 'expense' ? 'selected' : '' }}>Pengeluaran</option>
                <option value="income" {{ old('category_type') === 'income' ? 'selected' : '' }}>Pemasukan</option>
              </select>
            </div>
          </div>

          <div class="inline-alert" id="amountAlert">Masukkan nominal dulu ya. Contoh: 15.000 atau 250.000.</div>

          <div class="form-row">
            <div class="field">
              <label for="amount">Nominal</label>
              <div class="amount-wrap">
                <span>Rp</span>
                <input id="amount" type="text" name="amount" inputmode="numeric" value="{{ old('amount') ? number_format((int) preg_replace('/[^0-9]/', '', old('amount')), 0, ',', '.') : '' }}" placeholder="0" required>
              </div>
            </div>
            <div class="field">
              <label for="transaction_date">Tanggal</label>
              <input id="transaction_date" type="date" name="transaction_date" value="{{ old('transaction_date', date('Y-m-d')) }}" required>
            </div>
          </div>

          <div class="field">
            <label for="description">Keterangan</label>
            <textarea id="description" name="description" placeholder="Contoh: makan siang, gaji bulanan">{{ old('description') }}</textarea>
          </div>

          <button type="submit" class="primary-btn">Simpan Transaksi</button>
        </form>
      </div>
    </aside>

    <main class="panel">
      <div class="panel-head">
        <div>
          <h2 class="panel-title">Riwayat Transaksi</h2>
          <div class="panel-note">{{ $transactions->count() }} transaksi tersimpan.</div>
        </div>
      </div>
      <div class="table-wrap">
        <table class="transaction-table">
          <thead>
            <tr>
              <th>Transaksi</th>
              <th>Kategori</th>
              <th>Tipe</th>
              <th style="text-align:right;">Jumlah</th>
              <th style="text-align:right;">Aksi</th>
            </tr>
          </thead>
          <tbody>
            @forelse($transactions as $transaction)
              <tr>
                <td>
                  <div class="main-text">{{ $transaction->description ?: 'Tanpa keterangan' }}</div>
                  <div class="muted">{{ $transaction->transaction_date->format('d M Y') }}</div>
                </td>
                <td>{{ $transaction->category->name }}</td>
                <td><span class="pill {{ $transaction->category->type }}">{{ $transaction->category->type === 'income' ? 'Pemasukan' : 'Pengeluaran' }}</span></td>
                <td class="amount {{ $transaction->category->type }}">{{ $transaction->category->type === 'income' ? '+' : '-' }}Rp {{ number_format($transaction->amount, 0, ',', '.') }}</td>
                <td style="text-align:right;">
                  <form action="{{ route('transactions.destroy', $transaction->id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="button" class="delete-btn js-delete-transaction">Hapus</button>
                  </form>
                </td>
              </tr>
            @empty
              <tr>
                <td colspan="5"><div class="empty-box">Belum ada transaksi. Tambahkan kategori dulu kalau pilihan kategori masih kosong.</div></td>
              </tr>
            @endforelse
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>

<div class="modal-backdrop" id="deleteModal" aria-hidden="true">
  <div class="confirm-modal" role="dialog" aria-modal="true" aria-labelledby="deleteModalTitle">
    <div class="confirm-head">
      <div class="confirm-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 6h18"></path><path d="M8 6V4h8v2"></path><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v5"></path><path d="M14 11v5"></path>
        </svg>
      </div>
      <h2 class="confirm-title" id="deleteModalTitle">Hapus transaksi ini?</h2>
      <div class="confirm-text">Data transaksi akan dihapus dari riwayat. Kategori yang menempel pada transaksi ini juga ikut dibersihkan dan tidak akan kembali ke pilihan kategori.</div>
    </div>
    <div class="confirm-actions">
      <button type="button" class="modal-cancel" id="cancelDelete">Batal</button>
      <button type="button" class="modal-danger" id="confirmDelete">Hapus sekarang</button>
    </div>
  </div>
</div>

<script>
  (function() {
    const amountInput = document.getElementById('amount');
    const amountAlert = document.getElementById('amountAlert');
    const transactionForm = document.getElementById('transactionForm');
    if (!amountInput) return;

    const formatRupiah = (value) => {
      const digits = value.replace(/\D/g, '');
      return digits.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    };

    amountInput.addEventListener('input', function() {
      this.value = formatRupiah(this.value);
    });

    amountInput.addEventListener('focus', function() {
      if (amountAlert) amountAlert.style.display = 'none';
    });

    transactionForm?.addEventListener('submit', function(event) {
      const rawAmount = amountInput.value.replace(/\D/g, '');
      if (!rawAmount || Number(rawAmount) <= 0) {
        event.preventDefault();
        if (amountAlert) amountAlert.style.display = 'block';
        amountInput.focus();
        return;
      }

      amountInput.value = rawAmount;
    });
  })();

  (function() {
    const modal = document.getElementById('deleteModal');
    const cancelButton = document.getElementById('cancelDelete');
    const confirmButton = document.getElementById('confirmDelete');
    let activeForm = null;

    if (!modal || !cancelButton || !confirmButton) return;

    const openModal = (form) => {
      activeForm = form;
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
      cancelButton.focus();
    };

    const closeModal = () => {
      activeForm = null;
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
    };

    document.querySelectorAll('.js-delete-transaction').forEach((button) => {
      button.addEventListener('click', () => openModal(button.closest('form')));
    });

    cancelButton.addEventListener('click', closeModal);
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeModal();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && modal.classList.contains('is-open')) closeModal();
    });
    confirmButton.addEventListener('click', () => {
      if (activeForm) activeForm.submit();
    });
  })();
</script>
@endsection
