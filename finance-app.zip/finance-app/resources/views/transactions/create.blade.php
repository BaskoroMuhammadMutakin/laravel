@extends('layouts.app')
@section('title','Tambah Transaksi')

@section('content')
<style>
  .topbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 14px 22px;
    margin-bottom: 20px;
    box-shadow: var(--shadow-sm);
  }

  .topbar-brand h1 {
    font-family: var(--font-ser);
    font-size: 1.35rem;
    font-weight: 400;
    color: var(--text-1);
    line-height: 1;
  }

  .topbar-brand p {
    font-size: 12px;
    color: var(--text-3);
    font-weight: 300;
    margin-top: 2px;
  }

  .topbar-right {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .btn-back {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    border: 1px solid var(--border);
    background: transparent;
    color: var(--text-2);
    padding: 8px 14px;
    border-radius: var(--radius-sm);
    font-size: 13px;
    font-weight: 400;
    font-family: var(--font-sans);
    text-decoration: none;
    cursor: pointer;
    transition: background 0.2s;
  }
  .btn-back:hover { background: var(--surface); }

  .theme-btn {
    width: 36px; height: 36px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
    background: var(--surface);
    color: var(--text-2);
    cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: background 0.2s;
  }
  .theme-btn:hover { background: var(--border); }

  .avatar {
    width: 36px; height: 36px;
    background: var(--forest);
    color: var(--accent);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-weight: 500;
    font-size: 13px;
    font-family: var(--font-sans);
    overflow: hidden;
    flex-shrink: 0;
  }
  html[data-theme="dark"] .avatar { background: var(--forest-2); color: var(--accent-hover); }
  .avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }

  .flash-error {
    display: flex;
    align-items: center;
    gap: 10px;
    background: #fef2f2;
    border: 1px solid #fca5a5;
    color: #991b1b;
    padding: 12px 16px;
    border-radius: var(--radius-sm);
    margin-bottom: 18px;
    font-size: 13px;
  }
  html[data-theme="dark"] .flash-error {
    background: rgba(248,113,113,0.08);
    border-color: rgba(248,113,113,0.25);
    color: #f87171;
  }

  .form-panel {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    box-shadow: var(--shadow-md);
    max-width: 640px;
    overflow: hidden;
  }

  .form-panel-head {
    padding: 18px 24px;
    border-bottom: 1px solid var(--border);
  }

  .form-panel-title {
    font-family: var(--font-ser);
    font-size: 1.15rem;
    font-weight: 400;
    color: var(--text-1);
    line-height: 1;
  }

  .form-panel-sub {
    font-size: 12px;
    color: var(--text-3);
    font-weight: 300;
    margin-top: 3px;
  }

  .form-body { padding: 24px; }

  .ig { margin-bottom: 16px; }

  .ig label {
    display: block;
    font-size: 10.5px;
    font-weight: 500;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: var(--text-3);
    margin-bottom: 6px;
  }

  .ig input,
  .ig textarea {
    width: 100%;
    padding: 10px 14px;
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    background: var(--card);
    color: var(--text-1);
    font-size: 13px;
    font-family: var(--font-sans);
    font-weight: 400;
    outline: none;
    transition: border-color 0.2s, box-shadow 0.2s;
    appearance: none;
    -webkit-appearance: none;
  }

  .ig input:focus,
  .ig textarea:focus {
    border-color: var(--accent);
    box-shadow: 0 0 0 4px rgba(17,24,39,0.1);
  }

  .ig textarea {
    resize: vertical;
    min-height: 88px;
    line-height: 1.6;
  }

  .ig input::placeholder,
  .ig textarea::placeholder { color: var(--text-3); font-weight: 300; }

  .amt-wrap { position: relative; }
  .amt-prefix {
    position: absolute;
    left: 14px; top: 50%; transform: translateY(-50%);
    font-size: 12px; font-weight: 500;
    color: var(--text-3); pointer-events: none; user-select: none;
  }
  .amt-wrap input { padding-left: 40px; }

  .opt {
    font-size: 11px; font-weight: 300;
    color: var(--text-3); letter-spacing: 0; text-transform: none;
  }

  .form-divider {
    border: none;
    border-top: 1px solid var(--border);
    margin: 6px 0 20px;
  }

  .btn-submit {
    width: 100%;
    padding: 12px;
    background: var(--accent);
    color: var(--accent-text);
    border: none;
    border-radius: var(--radius-sm);
    font-size: 13px;
    font-weight: 500;
    font-family: var(--font-sans);
    cursor: pointer;
    transition: filter 0.2s, transform 0.1s;
    letter-spacing: 0.2px;
  }
  .btn-submit:hover  { filter: brightness(1.12); }
  .btn-submit:active { transform: scale(0.99); }

  /* ── KATEGORI PILL TOGGLE ────────────────────────────── */
  .cat-label {
    display: block;
    font-size: 10.5px;
    font-weight: 500;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    color: var(--text-3);
    margin-bottom: 10px;
  }

  .cat-group-label {
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 1.1px;
    text-transform: uppercase;
    color: var(--text-3);
    margin: 0 0 6px 2px;
  }

  .cat-toggle {
    display: grid;
    background: var(--surface);
    border-radius: var(--radius-sm);
    padding: 4px;
    gap: 4px;
    border: 1px solid var(--border);
    margin-bottom: 10px;
  }

  .cat-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 11px 10px;
    border-radius: calc(var(--radius-sm) - 2px);
    font-size: 13px;
    font-weight: 500;
    color: var(--text-2);
    background: transparent;
    border: 2px solid transparent;
    cursor: pointer;
    transition: all 0.2s;
    font-family: var(--font-sans);
  }

  .cat-btn:hover {
    background: var(--card);
    border-color: var(--border-strong);
  }

  /* Income aktif */
  .cat-btn.income.active {
    background: var(--card);
    color: #166534;
    border-color: #166534;
  }
  html[data-theme="dark"] .cat-btn.income.active {
    background: rgba(74,222,128,0.08);
    color: #4ade80;
    border-color: #4ade80;
  }

  /* Expense aktif */
  .cat-btn.expense.active {
    background: var(--card);
    color: #991b1b;
    border-color: #991b1b;
  }
  html[data-theme="dark"] .cat-btn.expense.active {
    background: rgba(248,113,113,0.08);
    color: #f87171;
    border-color: #f87171;
  }

  .cat-section { margin-bottom: 20px; }
</style>

{{-- TOPBAR --}}
<div class="topbar">
  <div class="topbar-brand">
    <h1>Tambah Transaksi</h1>
    <p>Catat pemasukan atau pengeluaran baru</p>
  </div>
  <div class="topbar-right">
    <a href="{{ route('transactions.index') }}" class="btn-back">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M19 12H5M12 19l-7-7 7-7"/>
      </svg>
      Kembali
    </a>
    <button id="themeToggle" class="theme-btn" title="Ganti tema" type="button">
      <svg id="themeIcon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
      </svg>
    </button>
    <div class="avatar">
      @if(auth()->user()->profile_photo_path)
        <img src="{{ url(auth()->user()->profile_photo_path) }}" alt="Avatar">
      @else
        {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
      @endif
    </div>
  </div>
</div>

{{-- ERROR --}}
@if($errors->any())
  <div class="flash-error">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0">
      <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
    </svg>
    {{ $errors->first() }}
  </div>
@endif

{{-- FORM PANEL --}}
<div class="form-panel">
  <div class="form-panel-head">
    <div class="form-panel-title">Form Transaksi</div>
    <div class="form-panel-sub">Isi semua field yang diperlukan</div>
  </div>

  <div class="form-body">
    <form method="POST" action="{{ route('transactions.store') }}">
      @csrf

      {{-- Hidden input category_id yang dikirim ke controller --}}
      <input type="hidden" name="category_id" id="selected_category_id" value="{{ old('category_id') }}">

      {{-- ── KATEGORI PILL TOGGLE ── --}}
      @php
        $incomeCategories  = $categories->filter(fn($c) => $c->type === 'income');
        $expenseCategories = $categories->filter(fn($c) => $c->type === 'expense');
        $oldCatId = old('category_id');
      @endphp

      <div class="cat-section">
        <span class="cat-label">Kategori</span>

        @if($incomeCategories->count() > 0)
          <p class="cat-group-label">📥 Pemasukan</p>
          <div class="cat-toggle" style="grid-template-columns: repeat({{ min($incomeCategories->count(), 3) }}, 1fr)">
            @foreach($incomeCategories as $cat)
              <button type="button"
                class="cat-btn income {{ $oldCatId == $cat->id ? 'active' : '' }}"
                data-id="{{ $cat->id }}"
                onclick="pilihKategori(this)">
                {{ $cat->name }}
              </button>
            @endforeach
          </div>
        @endif

        @if($expenseCategories->count() > 0)
          <p class="cat-group-label">📤 Pengeluaran</p>
          <div class="cat-toggle" style="grid-template-columns: repeat({{ min($expenseCategories->count(), 3) }}, 1fr)">
            @foreach($expenseCategories as $cat)
              <button type="button"
                class="cat-btn expense {{ $oldCatId == $cat->id ? 'active' : '' }}"
                data-id="{{ $cat->id }}"
                onclick="pilihKategori(this)">
                {{ $cat->name }}
              </button>
            @endforeach
          </div>
        @endif

        @error('category_id')
          <div style="margin-top:4px;color:#991b1b;font-size:12px;">{{ $message }}</div>
        @enderror
      </div>

      {{-- Tanggal --}}
      <div class="ig">
        <label for="transaction_date">Tanggal</label>
        <input id="transaction_date" type="date" name="transaction_date"
               value="{{ old('transaction_date', date('Y-m-d')) }}">
        @error('transaction_date')
          <div style="margin-top:4px;color:#991b1b;font-size:12px;">{{ $message }}</div>
        @enderror
      </div>

      {{-- Jumlah --}}
      <div class="ig">
        <label for="amount">Jumlah</label>
        <div class="amt-wrap">
          <span class="amt-prefix">Rp</span>
          <input id="amount" type="number" name="amount"
                 value="{{ old('amount') }}" placeholder="0" min="0">
        </div>
        @error('amount')
          <div style="margin-top:4px;color:#991b1b;font-size:12px;">{{ $message }}</div>
        @enderror
      </div>

      {{-- Keterangan --}}
      <div class="ig">
        <label for="description">
          Keterangan <span class="opt">(opsional)</span>
        </label>
        <textarea id="description" name="description"
                  placeholder="Contoh: makan siang, gaji bulanan…">{{ old('description') }}</textarea>
      </div>

      <hr class="form-divider">

      <button type="submit" class="btn-submit">Simpan Transaksi</button>
    </form>
  </div>
</div>

<script>
  // ── THEME TOGGLE ──────────────────────────────────────
  const root        = document.documentElement;
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon   = document.getElementById('themeIcon');

  const moonPath = `<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>`;
  const sunPaths = `<circle cx="12" cy="12" r="5"/>
    <line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
    <line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>`;

  const saved = localStorage.getItem('theme') || 'light';
  root.setAttribute('data-theme', saved);
  themeIcon.innerHTML = saved === 'dark' ? sunPaths : moonPath;

  themeToggle.addEventListener('click', () => {
    const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    themeIcon.innerHTML = next === 'dark' ? sunPaths : moonPath;
  });

  // ── PILIH KATEGORI ────────────────────────────────────
  function pilihKategori(btn) {
    // Hapus active dari semua tombol
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    // Set active
    btn.classList.add('active');
    // Isi hidden input yang dikirim ke controller
    document.getElementById('selected_category_id').value = btn.dataset.id;
  }
</script>

@endsection