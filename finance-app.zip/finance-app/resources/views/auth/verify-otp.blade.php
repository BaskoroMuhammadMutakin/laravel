<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Verifikasi OTP — KeuanganKu</title>
  <link rel="icon" type="image/svg+xml" href="{{ asset('images/money-curreny-svgrepo-com (1).svg') }}">
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <style>
    :root{--green:#2ecc71;--green-hover:#27ae60;--forest:#0d1f14;
      --surface:#f5faf6;--card-border:#e5ede8;--text-muted:#6b8f72;
      --label-color:#9eb8a5;--font-display:'DM Serif Display',serif;--font-body:'DM Sans',sans-serif}
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    body{font-family:var(--font-body);min-height:100vh;background:#e8f5e9;
      display:flex;align-items:center;justify-content:center;padding:32px 20px}
    .kk-auth-wrap{width:100%;max-width:420px}
    .kk-card{background:#fff;border:1px solid var(--card-border);border-radius:20px;
      padding:40px 36px;box-shadow:0 24px 64px rgba(10,26,14,0.12)}
    .kk-back{display:inline-flex;align-items:center;gap:8px;font-size:12.5px;
      font-weight:500;color:var(--text-muted);text-decoration:none;margin-bottom:28px;
      transition:color .18s,gap .18s}
    .kk-back:hover{color:var(--forest);gap:5px}
    .kk-header{text-align:center;margin-bottom:28px}
    .kk-icon-wrap{width:52px;height:52px;background:#eaf7ef;border-radius:14px;
      display:flex;align-items:center;justify-content:center;margin:0 auto 16px}
    .kk-title{font-family:var(--font-display);font-size:1.7rem;font-weight:400;
      color:var(--forest);margin-bottom:6px;line-height:1.2}
    .kk-subtitle{font-size:13px;color:var(--text-muted);line-height:1.6}
    .kk-alert{display:flex;align-items:flex-start;gap:10px;padding:12px 14px;
      border-radius:10px;font-size:12.5px;line-height:1.55;margin-bottom:20px}
    .kk-alert-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;margin-top:4px}
    .kk-alert-error{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}
    .kk-alert-error .kk-alert-dot{background:#ef4444}
    .kk-alert-success{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534}
    .kk-alert-success .kk-alert-dot{background:#22c55e}
    .kk-alert-warning{background:#fffbeb;border:1px solid #fde68a;color:#92400e}
    .kk-alert-warning .kk-alert-dot{background:#f59e0b}
    .kk-form-group{margin-bottom:16px}
    .kk-label{display:block;font-size:11.5px;font-weight:500;letter-spacing:.4px;
      color:var(--forest);margin-bottom:6px;text-transform:uppercase}
    .kk-input{width:100%;padding:11px 14px;border:1px solid var(--card-border);
      border-radius:10px;font-size:13.5px;font-family:var(--font-body);color:var(--forest);
      background:var(--surface);transition:border-color .18s,box-shadow .18s;-webkit-appearance:none}
    .kk-input:focus{outline:none;border-color:var(--green);background:#fff;
      box-shadow:0 0 0 3px rgba(46,204,113,.12)}
    .kk-input.is-invalid{border-color:#ef4444}
    .kk-input[readonly]{background:#f0f4f0;color:var(--text-muted);cursor:default}
    .kk-field-error{font-size:11.5px;color:#ef4444;margin-top:5px}

    /* OTP input khusus */
    .kk-otp-input{
      text-align:center;
      font-size:1.5rem;
      font-weight:500;
      letter-spacing:.5rem;
      padding:14px;
      background:#fff;
      border:1.5px solid var(--card-border);
    }
    .kk-otp-input:focus{
      border-color:var(--green);
      box-shadow:0 0 0 3px rgba(46,204,113,.12);
    }
    .kk-otp-input.is-invalid{border-color:#ef4444}

    .kk-email-chip{
      display:flex;
      align-items:center;
      gap:8px;
      background:var(--surface);
      border:1px solid var(--card-border);
      border-radius:10px;
      padding:10px 14px;
      font-size:13px;
      color:var(--forest);
      margin-bottom:16px;
    }
    .kk-email-chip svg{flex-shrink:0;color:var(--label-color)}

    .kk-btn-primary{display:flex;align-items:center;justify-content:space-between;
      width:100%;padding:13px 18px;background:var(--green);color:#0a1a0e;border:none;
      border-radius:10px;font-size:13.5px;font-weight:500;font-family:var(--font-body);
      cursor:pointer;transition:background .18s;margin-top:4px}
    .kk-btn-primary:hover{background:var(--green-hover)}
    .kk-divider{border:none;border-top:1px solid var(--card-border);margin:20px 0}
    .kk-footer-text{text-align:center;font-size:12.5px;color:var(--text-muted)}
    .kk-footer-text a{color:var(--forest);font-weight:500;text-decoration:none}
    .kk-footer-text a:hover{text-decoration:underline}
  </style>
</head>
<body>

<div class="kk-auth-wrap">
  <div class="kk-card">

    <a href="{{ route('password.forgot') }}" class="kk-back">
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 2L4 7l5 5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
      Kembali
    </a>

    <div class="kk-header">
      <div class="kk-icon-wrap">
        <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
          <rect x="3" y="6" width="16" height="12" rx="2.5" stroke="#2ecc71" stroke-width="1.6"/>
          <path d="M3 9l8 5 8-5" stroke="#2ecc71" stroke-width="1.6" stroke-linecap="round"/>
        </svg>
      </div>
      <h1 class="kk-title">Verifikasi <em style="font-style:italic;color:#27ae60">OTP</em></h1>
      <p class="kk-subtitle">Masukkan 6 digit kode yang dikirim ke email Anda</p>
    </div>

    @if(session('otp_sent'))
      <div class="kk-alert kk-alert-success">
        <div class="kk-alert-dot"></div>
        <div>Kode OTP telah dikirim ke email Anda.</div>
      </div>
    @endif

    @if(session('mail_error'))
      <div class="kk-alert kk-alert-warning">
        <div class="kk-alert-dot"></div>
        <div>{{ session('mail_error') }}</div>
      </div>
    @endif

    @if($errors->any())
      <div class="kk-alert kk-alert-error">
        <div class="kk-alert-dot"></div>
        <div>
          @foreach($errors->all() as $error){{ $error }}<br>@endforeach
        </div>
      </div>
    @endif

    <form method="POST" action="{{ route('password.verify-otp.post') }}">
      @csrf

      {{-- Email chip (readonly) --}}
      <div class="kk-email-chip">
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <rect x="1" y="3" width="12" height="8" rx="1.5" stroke="currentColor" stroke-width="1.2"/>
          <path d="M1 5l6 3.5L13 5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/>
        </svg>
        <span>{{ session('otp_email') ?? old('email') }}</span>
      </div>
      <input type="hidden" name="email" value="{{ session('otp_email') ?? old('email') }}">

      <div class="kk-form-group">
        <label for="otp" class="kk-label">Kode OTP</label>
        <input type="text" name="otp" id="otp"
          class="kk-input kk-otp-input @error('otp') is-invalid @enderror"
          placeholder="000000"
          maxlength="6"
          pattern="[0-9]{6}"
          inputmode="numeric"
          autocomplete="one-time-code"
          value="{{ old('otp') }}"
          required>
        @error('otp')
          <div class="kk-field-error">{{ $message }}</div>
        @enderror
      </div>

      <button type="submit" class="kk-btn-primary" id="kk-verify-btn">
        Verifikasi Kode
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path d="M2 7l4 4 6-7" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>

      <hr class="kk-divider">
      <p class="kk-footer-text">
        Tidak menerima kode? <a href="{{ route('password.forgot') }}">Kirim ulang</a>
      </p>
    </form>

  </div>
</div>

<script>
const otpInput = document.getElementById('otp');

otpInput.addEventListener('input', function () {
  this.value = this.value.replace(/[^0-9]/g, '');
  if (this.value.length === 6) {
    this.form.submit();
  }
});

document.addEventListener('DOMContentLoaded', () => otpInput.focus());
</script>
</body>
</html>