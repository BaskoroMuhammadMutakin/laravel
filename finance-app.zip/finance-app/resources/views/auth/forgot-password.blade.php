<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Lupa Password — KeuanganKu</title>
    <link rel="icon" type="image/svg+xml" href="{{ asset('images/money-curreny-svgrepo-com (1).svg') }}">
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <style>
    :root{--green:#2ecc71;--green-hover:#27ae60;--forest:#0d1f14;
      --surface:#f5faf6;--card-border:#e5ede8;--text-muted:#6b8f72;
      --label-color:#9eb8a5;--font-display:'DM Serif Display',serif;--font-body:'DM Sans',sans-serif}
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    body{font-family:var(--font-body);min-height:100vh;background:#e8f5e9;
      display:flex;align-items:center;justify-content:center;padding:32px 20px}
    .kk-auth-wrap{width:100%;max-width:420px}
    .kk-card{background:#fff;border:1px solid var(--card-border);border-radius:20px;
      padding:40px 36px;box-shadow:0 24px 64px rgba(10,26,14,0.12)}
    .kk-back{display:inline-flex;align-items:center;gap:8px;font-size:12.5px;
      font-weight:500;color:var(--text-muted);text-decoration:none;margin-bottom:28px;
      transition:color .18s,gap .18s}
    .kk-back:hover{color:var(--forest);gap:5px}
    .kk-header{text-align:center;margin-bottom:28px}
    .kk-icon-wrap{width:52px;height:52px;background:#eaf7ef;border-radius:14px;
      display:flex;align-items:center;justify-content:center;margin:0 auto 16px}
    .kk-title{font-family:var(--font-display);font-size:1.7rem;font-weight:400;
      color:var(--forest);margin-bottom:6px;line-height:1.2}
    .kk-subtitle{font-size:13px;color:var(--text-muted);line-height:1.6}
    .kk-alert{display:flex;align-items:flex-start;gap:10px;padding:12px 14px;
      border-radius:10px;font-size:12.5px;line-height:1.55;margin-bottom:20px}
    .kk-alert-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;margin-top:4px}
    .kk-alert-error{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}
    .kk-alert-error .kk-alert-dot{background:#ef4444}
    .kk-alert-success{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534}
    .kk-alert-success .kk-alert-dot{background:#22c55e}
    .kk-form-group{margin-bottom:20px}
    .kk-label{display:block;font-size:11.5px;font-weight:500;letter-spacing:.4px;
      color:var(--forest);margin-bottom:6px;text-transform:uppercase}
    .kk-input{width:100%;padding:11px 14px;border:1px solid var(--card-border);
      border-radius:10px;font-size:13.5px;font-family:var(--font-body);color:var(--forest);
      background:var(--surface);transition:border-color .18s,box-shadow .18s;-webkit-appearance:none}
    .kk-input:focus{outline:none;border-color:var(--green);background:#fff;
      box-shadow:0 0 0 3px rgba(46,204,113,.12)}
    .kk-input.is-invalid{border-color:#ef4444}
    .kk-field-error{font-size:11.5px;color:#ef4444;margin-top:5px}
    .kk-hint{font-size:12px;color:var(--text-muted);margin-top:6px;line-height:1.5}
    .kk-btn-primary{display:flex;align-items:center;justify-content:space-between;
      width:100%;padding:13px 18px;background:var(--green);color:#0a1a0e;border:none;
      border-radius:10px;font-size:13.5px;font-weight:500;font-family:var(--font-body);
      cursor:pointer;transition:background .18s}
    .kk-btn-primary:hover{background:var(--green-hover)}
    .kk-btn-primary:disabled{opacity:.5;cursor:not-allowed}
  </style>
</head>
<body>

<div class="kk-auth-wrap">
  <div class="kk-card">

    <a href="{{ route('login') }}" class="kk-back">
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 2L4 7l5 5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
      Kembali ke Login
    </a>

    <div class="kk-header">
      <div class="kk-icon-wrap">
        <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
          <circle cx="9" cy="9" r="4" stroke="#2ecc71" stroke-width="1.6"/>
          <path d="M12.5 12.5L18 18" stroke="#2ecc71" stroke-width="1.6" stroke-linecap="round"/>
          <path d="M9 7v2l1 1" stroke="#2ecc71" stroke-width="1.4" stroke-linecap="round"/>
        </svg>
      </div>
      <h1 class="kk-title">Lupa <em style="font-style:italic;color:#27ae60">password?</em></h1>
      <p class="kk-subtitle">Masukkan email terdaftar untuk menerima kode OTP verifikasi</p>
    </div>

    @if($errors->any())
      <div class="kk-alert kk-alert-error">
        <div class="kk-alert-dot"></div>
        <div>
          @foreach($errors->all() as $error){{ $error }}<br>@endforeach
        </div>
      </div>
    @endif

    @if(session('status'))
      <div class="kk-alert kk-alert-success">
        <div class="kk-alert-dot"></div>
        <div>{{ session('status') }}</div>
      </div>
    @endif

    <form method="POST" action="{{ route('password.send-otp') }}">
      @csrf

      <div class="kk-form-group">
        <label for="email" class="kk-label">Alamat Email</label>
        <input type="email" name="email" id="email"
          class="kk-input @error('email') is-invalid @enderror"
          placeholder="contoh@email.com"
          value="{{ old('email') }}" required autofocus>
        @error('email')
          <div class="kk-field-error">{{ $message }}</div>
        @enderror
        <p class="kk-hint">Kode OTP akan dikirim ke email ini jika terdaftar di sistem.</p>
      </div>

      <button type="submit" class="kk-btn-primary">
        Kirim Kode OTP
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path d="M2 7h10M8 3l4 4-4 4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button>
    </form>

  </div>
</div>

</body>
</html>