<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Masuk — KeuanganKu</title>
  <link rel="icon" type="image/svg+xml" href="{{ asset('images/money-curreny-svgrepo-com (1).svg') }}">
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <style>
    :root {
      --green:#2ecc71; --green-hover:#27ae60; --forest:#0d1f14;
      --surface:#f5faf6; --card-border:#e5ede8; --text-muted:#6b8f72;
      --label-color:#9eb8a5; --font-display:'DM Serif Display',serif;
      --font-body:'DM Sans',sans-serif;
    }
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    body{font-family:var(--font-body);min-height:100vh;background:#e8f5e9;
      display:flex;align-items:center;justify-content:center;padding:32px 20px}
    .kk-auth-wrap{width:100%;max-width:420px}
    .kk-card{background:#fff;border:1px solid var(--card-border);border-radius:20px;
      padding:40px 36px;box-shadow:0 24px 64px rgba(10,26,14,0.12)}
    .kk-back{display:inline-flex;align-items:center;gap:8px;font-size:12.5px;
      font-weight:500;color:var(--text-muted);text-decoration:none;margin-bottom:28px;
      transition:color .18s,gap .18s}
    .kk-back:hover{color:var(--forest);gap:5px}
    .kk-header{text-align:center;margin-bottom:28px}
    .kk-icon-wrap{width:52px;height:52px;background:#eaf7ef;border-radius:14px;
      display:flex;align-items:center;justify-content:center;margin:0 auto 16px}
    .kk-title{font-family:var(--font-display);font-size:1.7rem;font-weight:400;
      color:var(--forest);margin-bottom:6px;line-height:1.2}
    .kk-subtitle{font-size:13px;color:var(--text-muted);line-height:1.6}
    .kk-alert{display:flex;align-items:flex-start;gap:10px;padding:12px 14px;
      border-radius:10px;font-size:12.5px;line-height:1.55;margin-bottom:20px}
    .kk-alert-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;margin-top:4px}
    .kk-alert-error{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}
    .kk-alert-error .kk-alert-dot{background:#ef4444}
    .kk-form-group{margin-bottom:16px}
    .kk-label{display:block;font-size:11.5px;font-weight:500;letter-spacing:.4px;
      color:var(--forest);margin-bottom:6px;text-transform:uppercase}
    .kk-input{width:100%;padding:11px 14px;border:1px solid var(--card-border);
      border-radius:10px;font-size:13.5px;font-family:var(--font-body);color:var(--forest);
      background:var(--surface);transition:border-color .18s,box-shadow .18s;-webkit-appearance:none}
    .kk-input:focus{outline:none;border-color:var(--green);background:#fff;
      box-shadow:0 0 0 3px rgba(46,204,113,.12)}
    .kk-input.is-invalid{border-color:#ef4444}
    .kk-field-error{font-size:11.5px;color:#ef4444;margin-top:5px}
    .kk-pw-wrap{position:relative}
    .kk-pw-wrap .kk-input{padding-right:42px}
    .kk-pw-toggle{position:absolute;right:12px;top:50%;transform:translateY(-50%);
      background:none;border:none;cursor:pointer;color:var(--label-color);padding:0;
      display:flex;align-items:center;transition:color .18s}
    .kk-pw-toggle:hover{color:var(--forest)}
    .kk-form-row{display:flex;align-items:center;justify-content:space-between;
      margin:4px 0 20px}
    .kk-checkbox-label{display:flex;align-items:center;gap:8px;font-size:12.5px;
      color:var(--text-muted);cursor:pointer}
    .kk-checkbox-label input{width:15px;height:15px;accent-color:var(--green);cursor:pointer}
    .kk-link-sm{font-size:12.5px;color:var(--forest);font-weight:500;text-decoration:none}
    .kk-link-sm:hover{text-decoration:underline}
    .kk-btn-primary{display:flex;align-items:center;justify-content:space-between;
      width:100%;padding:13px 18px;background:var(--green);color:#0a1a0e;border:none;
      border-radius:10px;font-size:13.5px;font-weight:500;font-family:var(--font-body);
      cursor:pointer;transition:background .18s}
    .kk-btn-primary:hover{background:var(--green-hover)}
    .kk-divider{border:none;border-top:1px solid var(--card-border);margin:20px 0}
    .kk-footer-text{text-align:center;font-size:12.5px;color:var(--text-muted)}
    .kk-footer-text a{color:var(--forest);font-weight:500;text-decoration:none}
    .kk-footer-text a:hover{text-decoration:underline}
  </style>
</head>
<body>

<div class="kk-auth-wrap">
  <div class="kk-card">

    <a href="{{ route('welcome') }}" class="kk-back">
      <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 2L4 7l5 5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
      Kembali
    </a>

    <div class="kk-header">
      <div class="kk-icon-wrap">
        <img src="{{ asset('images/money-curreny-svgrepo-com (1).svg') }}" width="35" height="35" alt="KeuanganKu">
      </div>
      <h1 class="kk-title">Selamat datang<br><em style="font-style:italic;color:#27ae60">kembali</em></h1>
      <p class="kk-subtitle">Masuk ke akun KeuanganKu dan kelola keuanganmu</p>
    </div>

    @if($errors->any())
      <div class="kk-alert kk-alert-error">
        <div class="kk-alert-dot"></div>
        <div><strong>Gagal masuk</strong> — {{ $errors->first() }}</div>
      </div>
    @endif

    <form method="POST" action="{{ route('login.post') }}">
      @csrf

      <div class="kk-form-group">
        <label for="email" class="kk-label">Alamat Email</label>
        <input type="email" name="email" id="email"
          class="kk-input @error('email') is-invalid @enderror"
          placeholder="contoh@email.com"
          value="{{ old('email') }}" autofocus>
        @error('email')
          <div class="kk-field-error">{{ $message }}</div>
        @enderror
      </div>

      <div class="kk-form-group">
        <label for="password" class="kk-label">Kata Sandi</label>
        <div class="kk-pw-wrap">
          <input type="password" name="password" id="password"
            class="kk-input"
            placeholder="Masukkan kata sandi">
          <button type="button" class="kk-pw-toggle" onclick="kkTogglePw('password','icon-pw')">
            <svg id="icon-pw" width="16" height="16" viewBox="0 0 16 16" fill="none">
              <ellipse cx="8" cy="8" rx="6" ry="4" stroke="currentColor" stroke-width="1.3"/>
              <circle cx="8" cy="8" r="1.8" fill="currentColor"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="kk-form-row">
        <label class="kk-checkbox-label">
          <input type="checkbox" name="remember" id="remember">
          <span>Ingat saya</span>
        </label>
        <a href="{{ route('password.forgot') }}" class="kk-link-sm">Lupa password?</a>
      </div>

      <button type="submit" class="kk-btn-primary">
        Masuk ke Akun
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M5 2l5 5-5 5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>

      <hr class="kk-divider">
      <p class="kk-footer-text">
        Belum punya akun? <a href="{{ route('register.user') }}">Daftar sekarang</a>
      </p>
    </form>

  </div>
</div>

<script>
function kkTogglePw(inputId, iconId) {
  const inp = document.getElementById(inputId);
  const ico = document.getElementById(iconId);
  const isHidden = inp.type === 'password';
  inp.type = isHidden ? 'text' : 'password';
  ico.innerHTML = isHidden
    ? '<path d="M2 2l12 12M6.5 6.6A1.8 1.8 0 0010 9.5M4.2 4.4C2.9 5.3 2 6.5 2 8c0 0 2 4 6 4a6 6 0 002.4-.5M7 3.1A6 6 0 0114 8c0 .8-.3 1.6-.7 2.3" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>'
    : '<ellipse cx="8" cy="8" rx="6" ry="4" stroke="currentColor" stroke-width="1.3"/><circle cx="8" cy="8" r="1.8" fill="currentColor"/>';
}
</script>
</body>
</html>