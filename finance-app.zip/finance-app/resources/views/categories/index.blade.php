@extends('layouts.app')
@section('title','Kategori')

@section('content')
<style>
  :root {
    --forest: #111827;
    --surface: #f5faf6;
    --card: #ffffff;
    --border: #dae8d9;
    --border-strong: #c4dcc9;
    --text-1: #0d1f14;
    --text-2: #4f7060;
    --text-3: #8ba593;
    --accent: #111827;
    --accent-hover: #1f2937;
    --accent-text: #ffffff;
    --income: #166534;
    --expense: #991b1b;
    --shadow-sm: 0 1px 6px rgba(13,31,20,0.06);
    --shadow-md: 0 6px 18px rgba(13,31,20,0.08);
    --radius: 8px;
    --font-ser: var(--font-sans);
    --font-sans: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  }

  [data-theme="dark"] {
    --surface: #0b1c13;
    --card: #122918;
    --border: #1f3f2d;
    --border-strong: #29503a;
    --text-1: #f4fbf5;
    --text-2: #97d5a0;
    --text-3: #658f72;
    --accent: #4ade80;
    --accent-hover: #16a34a;
    --accent-text: #0f2218;
    --shadow-sm: 0 1px 6px rgba(0,0,0,0.2);
    --shadow-md: 0 6px 18px rgba(0,0,0,0.35);
  }

  *, *::before, *::after { box-sizing: border-box; }
  body { margin: 0; font-family: var(--font-sans); background: var(--surface); color: var(--text-1); }

  .topbar { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:18px; margin-bottom:24px; }
  .page-title { margin:0; font-family:var(--font-sans); font-size:1.8rem; font-weight:800; letter-spacing:0; }
  .page-subtitle { margin-top:8px; color:var(--text-3); font-size:14px; line-height:1.7; }
  .topbar-actions { display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
  #themeToggle { width:46px; height:46px; border-radius:14px; border:1px solid var(--border); background:var(--card); color:var(--text-1); display:grid; place-items:center; cursor:pointer; transition:transform .2s ease; }
  #themeToggle:hover { transform:translateY(-1px); }
  .avatar {
    width: 36px; height: 36px;
    background: var(--forest);
    color: var(--accent);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-weight: 500;
    font-size: 13px;
    font-family: var(--font-sans);
    overflow: hidden;
    flex-shrink: 0;
  }

  [data-theme="dark"] .avatar {
    background: var(--forest-2);
    color: var(--accent-hover);
  }

  .flash { background: rgba(17,24,39,0.06); border:1px solid rgba(17,24,39,0.12); color:var(--text-1); border-radius:16px; padding:16px 20px; margin-bottom:22px; font-weight:600; }

  .card-row { display:grid; grid-template-columns:1fr 420px; gap:22px; align-items:start; }
  @media(max-width:860px){ .card-row{grid-template-columns:1fr;} }

  .panel { background:var(--card); border:1px solid var(--border); border-radius:var(--radius); box-shadow:var(--shadow-sm); padding:24px; }
  .card-title { font-size:1rem; font-weight:700; color:var(--text-1); margin:0 0 18px; letter-spacing:-0.1px; }

  .table-simple { width:100%; border-collapse:collapse; }
  .table-simple th { text-align:left; padding:12px 14px; font-size:.68rem; font-weight:700; color:var(--text-3); text-transform:uppercase; letter-spacing:1px; border-bottom:1px solid var(--border); }
  .table-simple td { padding:15px 14px; font-size:.95rem; color:var(--text-2); border-bottom:1px solid var(--border); vertical-align:middle; }
  .table-simple tr:last-child td{border-bottom:none;}
  .table-simple tbody tr:hover td{background:var(--surface);}

  .status-chip { display:inline-flex; align-items:center; justify-content:center; padding:7px 14px; border-radius:999px; font-size:.78rem; font-weight:700; letter-spacing:.4px; text-transform:uppercase; }
  .status-chip.income { background: rgba(22,101,52,0.12); color: var(--income); }
  .status-chip.expense{ background: rgba(185,28,28,0.12); color: var(--expense); }

  .input-group { margin-bottom:18px; }
  .input-group label { display:block; font-size:.82rem; font-weight:600; color:var(--text-3); margin-bottom:7px; letter-spacing:.1px; }
  .input-group input, .input-group select { width:100%; padding:13px 14px; border-radius:14px; border:1px solid var(--border); background:var(--surface); color:var(--text-1); font-size:.95rem; outline:none; transition:border-color .18s, box-shadow .18s; appearance:none; }
  .input-group input:focus, .input-group select:focus { border-color: var(--accent); box-shadow:0 0 0 3px rgba(17,24,39,0.16); }
  .select-wrapper { position:relative; }
  .select-wrapper::after { content:'▾'; position:absolute; right:14px; top:50%; transform:translateY(-50%); color:var(--text-3); pointer-events:none; font-size:.85rem; }

  .button { display:inline-flex; align-items:center; justify-content:center; gap:8px; width:100%; padding:14px 0; border:none; border-radius:14px; background:var(--accent); color:var(--accent-text); font-size:.95rem; font-weight:700; cursor:pointer; transition:transform .2s ease, filter .2s ease; text-decoration:none; }
  .button:hover { transform:translateY(-1px); filter:brightness(1.03); }
  .button.danger { background: transparent; color: var(--expense); border: 1px solid rgba(153,27,27,0.18); width: auto; padding: 10px 16px; }
  .button.danger:hover { background: rgba(248,113,113,0.08); }

  .empty-state { padding:34px 10px; text-align:center; color:var(--text-3); font-size:.95rem; }
  .empty-state svg{margin-bottom:10px;color:var(--text-3);}
</style>

<div class="topbar">
  <div>
    <h1 class="page-title">Kategori</h1>
    <div class="page-subtitle">Atur kategori pemasukan dan pengeluaran Anda.</div>
  </div>
  <div class="topbar-actions">
    <button id="themeToggle" type="button" title="Ganti tema"></button>
    <div class="avatar">
      @if(auth()->user()->profile_photo_path)
        <img src="{{ url(auth()->user()->profile_photo_path) }}" alt="Avatar" style="width:100%;height:100%;object-fit:cover;border-radius:14px;">
      @else
        {{ strtoupper(substr(auth()->user()->name,0,1)) }}
      @endif
    </div>
  </div>
</div>

@if(session('success'))
  <div class="flash">{{ session('success') }}</div>
@endif

<div class="card-row">
  <div class="panel">
    <div class="card-title">Daftar Kategori</div>
    <table class="table-simple">
      <thead>
        <tr>
          <th>#</th>
          <th>Nama</th>
          <th>Tipe</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        @forelse($categories as $i => $category)
          <tr>
            <td class="text-muted" style="width:36px;">{{ $i + 1 }}</td>
            <td style="font-weight:600;">{{ $category->name }}</td>
            <td>
              <span class="status-chip {{ $category->type }}">
                {{ $category->type === 'income' ? 'Pemasukan' : 'Pengeluaran' }}
              </span>
            </td>
            <td>
              <form action="{{ route('categories.destroy', $category->id) }}" method="POST" style="display:inline-block;">
                @csrf
                @method('DELETE')
                <button type="submit" class="button danger" onclick="return confirm('Hapus kategori ini?');">
                  Hapus
                </button>
              </form>
            </td>
          </tr>
        @empty
          <tr>
            <td colspan="3">
              <div class="empty-state">
                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><line x1="7" y1="9" x2="17" y2="9"/><line x1="7" y1="13" x2="13" y2="13"/></svg>
                <div>Belum ada kategori tersimpan.</div>
              </div>
            </td>
          </tr>
        @endforelse
      </tbody>
    </table>
  </div>

  <div class="panel">
    <div class="card-title">Tambah Kategori Baru</div>
    <form method="POST" action="{{ route('categories.store') }}">
      @csrf

      <div class="input-group">
        <label for="name">Nama Kategori</label>
        <input id="name" type="text" name="name" value="{{ old('name') }}" placeholder="Contoh: Gaji, Makanan, Transportasi" required>
      </div>

      <div class="input-group">
        <label for="type">Tipe</label>
        <div class="select-wrapper">
          <select id="type" name="type">
            <option value="income" {{ old('type') == 'income' ? 'selected' : '' }}>Pemasukan</option>
            <option value="expense" {{ old('type') == 'expense' ? 'selected' : '' }}>Pengeluaran</option>
          </select>
        </div>
      </div>

      <button type="submit" class="button">+ Tambah Kategori</button>
    </form>
  </div>
</div>
@endsection
