<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $userId = auth()->id();

        $transactions = Transaction::with('category')
            ->where('user_id', $userId)
            ->whereHas('category') // Only include transactions with valid categories
            ->latest()
            ->take(6)
            ->get();

        $totalBalance = Transaction::with('category')
            ->where('user_id', $userId)
            ->get()
            ->sum(function ($t) {
                if (!$t->category) {
                    return 0; // Skip transactions with null categories
                }
                return $t->category->type === 'income'
                    ? $t->amount
                    : -$t->amount;
            });

        $monthlyIncome = Transaction::where('user_id', $userId)
            ->whereHas('category', fn ($q) => $q->where('type', 'income'))
            ->whereMonth('transaction_date', now()->month)
            ->whereYear('transaction_date', now()->year)
            ->sum('amount');

        $monthlyExpense = Transaction::where('user_id', $userId)
            ->whereHas('category', fn ($q) => $q->where('type', 'expense'))
            ->whereMonth('transaction_date', now()->month)
            ->whereYear('transaction_date', now()->year)
            ->sum('amount');

        $chartData = Transaction::with('category')
            ->where('user_id', $userId)
            ->whereHas('category') // Only include transactions with valid categories
            ->get()
            ->groupBy(fn ($t) => $t->category->name)
            ->map(fn ($items) => $items->sum('amount'))
            ->sortDesc();

        return view('dashboard.index', compact(
            'transactions',
            'totalBalance',
            'monthlyIncome',
            'monthlyExpense',
            'chartData'
        ));
    }
}
