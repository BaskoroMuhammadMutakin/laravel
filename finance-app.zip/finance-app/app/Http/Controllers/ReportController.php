<?php

namespace App\Http\Controllers;

use App\Models\Transaction;

class ReportController extends Controller
{
    public function index()
    {
        $userId = auth()->id();

        $transactions = Transaction::with('category')
            ->where('user_id', $userId)
            ->whereHas('category') // Only include transactions with valid categories
            ->get();

        // 📊 Ringkasan bulanan
        $monthlySummary = $transactions
            ->groupBy(fn ($t) => $t->transaction_date->format('M Y'))
            ->map(function ($items) {
                return [
                    'income' => $items->filter(fn ($item) => $item->category->type === 'income')->sum('amount'),
                    'expense' => $items->filter(fn ($item) => $item->category->type === 'expense')->sum('amount'),
                    'count' => $items->count(),
                ];
            })
            ->reverse()
            ->take(6);

        // 🏆 Top kategori (dibuat jadi struktur rapi)
        $topCategories = $transactions
            ->groupBy(fn ($t) => $t->category->name)
            ->map(function ($items, $name) {
                return [
                    'name' => $name,
                    'amount' => $items->sum('amount'),
                ];
            })
            ->sortByDesc('amount')
            ->take(5)
            ->values();

        return view('reports.index', compact('monthlySummary', 'topCategories'));
    }

    public function export()
    {
        $transactions = Transaction::with('category')
            ->where('user_id', auth()->id())
            ->whereHas('category')
            ->orderByDesc('transaction_date')
            ->get();

        $fileName = 'laporan-transaksi-' . now()->format('Y-m-d') . '.csv';

        return response()->streamDownload(function () use ($transactions) {
            $file = fopen('php://output', 'w');
            fwrite($file, "\xEF\xBB\xBF");

            fputcsv($file, [
                'Tanggal',
                'Pemasukan',
                'Pengeluaran',
            ]);

            foreach ($transactions->reverse() as $transaction) {
                $isIncome = $transaction->category->type === 'income';
                $income = $isIncome ? $transaction->amount : 0;
                $expense = $isIncome ? 0 : $transaction->amount;

                fputcsv($file, [
                    $transaction->transaction_date->format('Y-m-d'),
                    $income,
                    $expense,
                ]);
            }

            fclose($file);
        }, $fileName, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }
}
