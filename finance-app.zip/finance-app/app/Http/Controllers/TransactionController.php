<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\Category;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function index()
    {
        Category::doesntHave('transactions')
            ->where('user_id', auth()->id())
            ->delete();

        $transactions = Transaction::with('category')
            ->where('user_id', auth()->id())
            ->whereHas('category')
            ->latest()
            ->get();

        $categories = Category::withCount('transactions')
            ->where('user_id', auth()->id())
            ->orderBy('type')
            ->orderBy('name')
            ->get();

        $incomeTotal = $transactions
            ->filter(fn ($transaction) => $transaction->category->type === 'income')
            ->sum('amount');

        $expenseTotal = $transactions
            ->filter(fn ($transaction) => $transaction->category->type === 'expense')
            ->sum('amount');

        $totalBalance = $incomeTotal - $expenseTotal;

        return view('transactions.index', compact(
            'transactions',
            'categories',
            'incomeTotal',
            'expenseTotal',
            'totalBalance'
        ));
    }

    public function create()
    {
        return redirect()->route('transactions.index');
    }

    public function store(Request $request)
    {
        $request->merge([
            'amount' => preg_replace('/[^0-9]/', '', (string) $request->amount),
        ]);

        $request->validate([
            'category_name'    => 'required|string|max:100',
            'category_type'    => 'required|in:income,expense',
            'amount'           => 'required|numeric|min:1',
            'transaction_date' => 'required|date',
            'description'      => 'nullable|string|max:255',
        ]);

        $category = Category::create([
            'name' => $request->category_name,
            'type' => $request->category_type,
            'user_id' => auth()->id(),
        ]);

        Transaction::create([
            'user_id'          => auth()->id(),   // pakai user yang sedang login
            'category_id'      => $category->id,
            'amount'           => $request->amount,
            'transaction_date' => $request->transaction_date,
            'description'      => $request->description,
        ]);

        return redirect()->route('transactions.index')
            ->with('success', 'Transaksi berhasil ditambahkan!');
    }

    public function destroy($id)
    {
        $transaction = Transaction::with('category')
            ->where('user_id', auth()->id())
            ->findOrFail($id);

        $category = $transaction->category;
        $transaction->delete();

        if ($category && $category->user_id === auth()->id() && $category->transactions()->count() === 0) {
            $category->delete();
        }

        return redirect()->route('transactions.index')
            ->with('success', 'Transaksi dan kategorinya berhasil dihapus.');
    }
}
