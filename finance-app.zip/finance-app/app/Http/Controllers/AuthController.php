<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\PasswordReset;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;

class AuthController extends Controller
{
    // FORM REGISTER
    public function form()
    {
        return view('auth.register-user');
    }

    // SIMPAN USER
    public function storeUser(Request $request)
    {
        $request->validate([
            'email'    => 'required|email|unique:users,email',
            'password' => 'required|min:6',
            'nik'      => 'nullable|string',
        ]);

        User::create([
            'name'     => 'User', // default
            'email'    => $request->email,
            'password' => Hash::make($request->password),
            'nik'      => $request->input('nik'),
        ]);

        return redirect()->route('welcome')->with('modal_pending', true);
    }

    // LOGIN
    public function login(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required',
        ]);

        if (Auth::attempt([
            'email' => $request->email,
            'password' => $request->password
        ])) {
            return redirect()->route('dashboard');
        }

        return back()->withErrors(['email' => 'Email atau password salah']);
    }

    // LOGOUT
    public function logout()
    {
        Auth::logout();
        return redirect()->route('welcome');
    }

    // FORGOT PASSWORD - Show form
    public function showForgotPasswordForm()
    {
        return view('auth.forgot-password');
    }

    // FORGOT PASSWORD - Send OTP
    public function sendOtp(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email'
        ]);

        $email = $request->email;

        // Delete any existing OTP for this email
        PasswordReset::where('email', $email)->delete();

        // Generate 6-digit OTP
        $otp = PasswordReset::generateOtp();

        // Save OTP to database (expires in 10 minutes)
        PasswordReset::create([
            'email' => $email,
            'otp' => $otp,
            'expires_at' => Carbon::now()->addMinutes(10)
        ]);

        // Send OTP via email
        try {
            Mail::to($email)->send(new \App\Mail\SendOtp($otp));
        } catch (\Exception $e) {
            session()->flash('mail_error', 'Mail error: ' . $e->getMessage());
        }

        session(['otp_email' => $email]);

        return redirect()->route('password.verify-otp')
            ->with('otp_sent', true)
            ->with('email', $email);
    }

    // VERIFY OTP - Show form
    public function showVerifyOtpForm()
    {
        return view('auth.verify-otp');
    }

    // VERIFY OTP - Verify code
    public function verifyOtp(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'otp' => 'required|string|size:6'
        ]);

        $email = $request->email;
        $otp = $request->otp;

        $passwordReset = PasswordReset::where('email', $email)
            ->where('otp', $otp)
            ->first();

        if (!$passwordReset) {
            return back()->withErrors(['otp' => 'Kode OTP tidak valid']);
        }

        if ($passwordReset->isExpired()) {
            return back()->withErrors(['otp' => 'Kode OTP telah kedaluwarsa']);
        }

        // OTP is valid, store in session for password reset
        session(['verified_email' => $email]);

        // Delete the used OTP
        $passwordReset->delete();

        return redirect()->route('password.reset');
    }

    // RESET PASSWORD - Show form
    public function showResetPasswordForm()
    {
        if (!session('verified_email')) {
            return redirect()->route('password.forgot');
        }

        return view('auth.reset-password');
    }

    // RESET PASSWORD - Update password
    public function resetPassword(Request $request)
    {
        $request->validate([
            'password' => 'required|min:6|confirmed'
        ]);

        $email = session('verified_email');

        if (!$email) {
            return redirect()->route('password.forgot');
        }

        // Update user password
        $user = User::where('email', $email)->first();
        $user->password = Hash::make($request->password);
        $user->save();

        // Clear session
        session()->forget(['verified_email', 'otp_email']);

        return redirect()->route('login')->with('success', 'Password berhasil diubah. Silakan login dengan password baru.');
    }
}