<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class SettingsController extends Controller
{
    public function index()
    {
        return view('settings.index');
    }

    public function update(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'profile_photo' => 'nullable|image|mimes:jpg,jpeg,png,gif|max:2048',
        ]);

        $user = auth()->user();
        $user->name = $request->name;

        if ($request->hasFile('profile_photo')) {
            $photo = $request->file('profile_photo');
            $uploadFolder = public_path('uploads/profile_photos');

            if (!File::exists($uploadFolder)) {
                File::makeDirectory($uploadFolder, 0755, true);
            }

            if ($user->profile_photo_path && File::exists(public_path($user->profile_photo_path))) {
                File::delete(public_path($user->profile_photo_path));
            }

            $filename = time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $photo->getClientOriginalName());
            $photo->move($uploadFolder, $filename);
            $user->profile_photo_path = 'uploads/profile_photos/' . $filename;
        }

        $user->save();

        return back()->with('success', 'Profil berhasil diperbarui.');
    }
}
