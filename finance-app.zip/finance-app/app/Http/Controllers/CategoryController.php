<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::where('user_id', auth()->id())
            ->orderBy('type')
            ->latest()
            ->get();
        return view('categories.index', compact('categories'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:100',
            'type' => 'required|in:income,expense',
        ]);

        Category::create([
            'name' => $request->name,
            'type' => $request->type,
            'user_id' => auth()->id(),
        ]);

        return redirect()->route('transactions.index')
            ->with('success', 'Kategori berhasil ditambahkan.');
    }

    public function destroy($id)
    {
        $kategori = Category::where('user_id', auth()->id())->findOrFail($id);
        $kategori->transactions()->delete();
        $kategori->delete();

        return redirect()->route('transactions.index')
            ->with('success', 'Kategori berhasil dihapus.');
    }
}
