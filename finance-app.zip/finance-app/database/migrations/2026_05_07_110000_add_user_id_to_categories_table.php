<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // Check if user_id column exists, if not add it
        if (!Schema::hasColumn('categories', 'user_id')) {
            Schema::table('categories', function (Blueprint $table) {
                $table->foreignId('user_id')->after('id');
            });
        }

        // Assign existing categories to the first user if they don't have user_id
        $firstUser = DB::table('users')->first();
        if ($firstUser) {
            DB::table('categories')->whereNull('user_id')->update(['user_id' => $firstUser->id]);
        }

        // Add foreign key constraint if it doesn't exist
        Schema::table('categories', function (Blueprint $table) {
            if (!$this->foreignKeyExists('categories', 'categories_user_id_foreign')) {
                $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            }
        });
    }

    public function down(): void
    {
        Schema::table('categories', function (Blueprint $table) {
            if ($this->foreignKeyExists('categories', 'categories_user_id_foreign')) {
                $table->dropForeign(['user_id']);
            }
            if (Schema::hasColumn('categories', 'user_id')) {
                $table->dropColumn('user_id');
            }
        });
    }

    private function foreignKeyExists($table, $foreignKeyName)
    {
        $conn = Schema::getConnection();
        $dbName = $conn->getDatabaseName();
        $foreignKeys = $conn->select("
            SELECT CONSTRAINT_NAME
            FROM information_schema.TABLE_CONSTRAINTS
            WHERE CONSTRAINT_SCHEMA = ?
            AND TABLE_NAME = ?
            AND CONSTRAINT_NAME = ?
            AND CONSTRAINT_TYPE = 'FOREIGN KEY'
        ", [$dbName, $table, $foreignKeyName]);

        return count($foreignKeys) > 0;
    }
};