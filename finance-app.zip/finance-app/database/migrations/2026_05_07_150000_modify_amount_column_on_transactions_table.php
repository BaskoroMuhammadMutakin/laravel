<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement('ALTER TABLE transactions MODIFY amount BIGINT NOT NULL');
    }

    public function down(): void
    {
        DB::statement('ALTER TABLE transactions MODIFY amount INT NOT NULL');
    }
};
