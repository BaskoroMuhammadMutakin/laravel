<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $user = User::firstOrCreate([
            'email' => 'test@example.com',
        ], [
            'name' => 'Test User',
            'password' => bcrypt('password'),
        ]);

        $categories = [
            ['name' => 'Gaji', 'type' => 'income'],
            ['name' => 'Penjualan', 'type' => 'income'],
            ['name' => 'Makanan', 'type' => 'expense'],
            ['name' => 'Transportasi', 'type' => 'expense'],
            ['name' => 'Hiburan', 'type' => 'expense'],
        ];

        foreach ($categories as $data) {
            Category::firstOrCreate([
                'name' => $data['name'],
                'type' => $data['type'],
                'user_id' => $user->id,
            ]);
        }

        if (Transaction::where('user_id', $user->id)->count() === 0) {
            $makan = Category::where('name', 'Makanan')->first();
            $gaji = Category::where('name', 'Gaji')->first();
            $transport = Category::where('name', 'Transportasi')->first();

            Transaction::create([
                'user_id' => $user->id,
                'category_id' => $gaji->id,
                'amount' => 8500000,
                'transaction_date' => now()->subDays(3)->toDateString(),
                'description' => 'Gaji bulanan',
            ]);
            Transaction::create([
                'user_id' => $user->id,
                'category_id' => $makan->id,
                'amount' => 120000,
                'transaction_date' => now()->subDays(2)->toDateString(),
                'description' => 'Belanja bahan makanan',
            ]);
            Transaction::create([
                'user_id' => $user->id,
                'category_id' => $transport->id,
                'amount' => 45000,
                'transaction_date' => now()->subDay()->toDateString(),
                'description' => 'Ojek online',
            ]);
        }
    }
}
