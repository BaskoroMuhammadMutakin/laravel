<?php $__env->startSection('title','Laporan'); ?>

<?php $__env->startSection('content'); ?>
<style>
  .report-page { display:grid; gap:20px; }
  .report-top { display:flex; align-items:flex-start; justify-content:space-between; gap:16px; flex-wrap:wrap; }
  .report-title { margin:0; color:var(--text-1); font-size:1.8rem; font-weight:750; letter-spacing:0; }
  .report-subtitle { margin-top:6px; color:var(--text-3); font-size:13px; line-height:1.6; }
  .report-actions { display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
  .export-btn {
    display:inline-flex; align-items:center; justify-content:center; min-height:44px; padding:0 16px;
    border-radius:8px; border:1px solid transparent; background:var(--accent); color:var(--accent-text);
    font-size:13px; font-weight:800; text-decoration:none;
  }
  .report-grid { display:grid; grid-template-columns:1fr 340px; gap:20px; align-items:start; }
  .report-panel { background:var(--card); border:1px solid var(--border); border-radius:8px; box-shadow:var(--shadow-sm); overflow:hidden; }
  .panel-head { padding:18px 20px; border-bottom:1px solid var(--border); }
  .panel-title { margin:0; color:var(--text-1); font-size:1rem; font-weight:800; }
  .panel-note { margin-top:5px; color:var(--text-3); font-size:12px; line-height:1.5; }
  .table-wrap { overflow-x:auto; }
  .report-table { width:100%; min-width:620px; border-collapse:collapse; }
  .report-table th { text-align:left; padding:13px 16px; background:var(--surface); color:var(--text-3); border-bottom:1px solid var(--border); font-size:11px; font-weight:800; letter-spacing:.8px; text-transform:uppercase; }
  .report-table td { padding:15px 16px; border-bottom:1px solid var(--border); color:var(--text-2); font-size:13px; vertical-align:middle; }
  .report-table tr:last-child td { border-bottom:0; }
  .income-text { color:var(--income); font-weight:850; }
  .expense-text { color:var(--expense); font-weight:850; }
  .count-text { text-align:right; color:var(--text-1); font-weight:800; }
  .side-body { display:grid; gap:10px; padding:18px; }
  .category-item { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:12px; border:1px solid var(--border); border-radius:8px; background:var(--surface); }
  .category-name { color:var(--text-1); font-size:13px; font-weight:800; }
  .category-rank { margin-top:4px; color:var(--text-3); font-size:12px; }
  .category-amount { color:var(--text-2); font-size:13px; font-weight:850; white-space:nowrap; }
  .empty-state { padding:30px 16px; text-align:center; color:var(--text-3); font-size:13px; line-height:1.6; }
  @media(max-width:900px){ .report-grid{grid-template-columns:1fr;} }
</style>

<div class="report-page">
  <div class="report-top">
    <div>
      <h1 class="report-title">Laporan</h1>
      <div class="report-subtitle">Ringkasan transaksi dan export data ke Excel.</div>
    </div>
    <div class="report-actions">
      <a href="<?php echo e(route('reports.export')); ?>" class="export-btn">Export Excel</a>
      <button id="themeToggle" type="button" aria-label="Ganti tema"></button>
    </div>
  </div>

  <div class="report-grid">
    <section class="report-panel">
      <div class="panel-head">
        <h2 class="panel-title">Ringkasan Bulanan</h2>
        <div class="panel-note">Enam bulan terakhir berdasarkan transaksi tersimpan.</div>
      </div>
      <div class="table-wrap">
        <table class="report-table">
          <thead>
            <tr>
              <th>Bulan</th>
              <th>Pemasukan</th>
              <th>Pengeluaran</th>
              <th style="text-align:right;">Transaksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $monthlySummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $summary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td style="font-weight:800;color:var(--text-1);"><?php echo e($month); ?></td>
                <td class="income-text">Rp <?php echo e(number_format($summary['income'],0,',','.')); ?></td>
                <td class="expense-text">Rp <?php echo e(number_format($summary['expense'],0,',','.')); ?></td>
                <td class="count-text"><?php echo e($summary['count']); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="4"><div class="empty-state">Belum ada data laporan.</div></td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </section>

    <aside class="report-panel">
      <div class="panel-head">
        <h2 class="panel-title">Top Kategori</h2>
        <div class="panel-note">Kategori dengan nominal terbesar.</div>
      </div>
      <div class="side-body">
        <?php $__empty_1 = true; $__currentLoopData = $topCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="category-item">
            <div>
              <div class="category-name"><?php echo e($item['name']); ?></div>
              <div class="category-rank">#<?php echo e($loop->iteration); ?></div>
            </div>
            <div class="category-amount">Rp <?php echo e(number_format($item['amount'],0,',','.')); ?></div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="empty-state">Belum ada kategori transaksi.</div>
        <?php endif; ?>
      </div>
    </aside>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel11\finance-app\resources\views/reports/index.blade.php ENDPATH**/ ?>