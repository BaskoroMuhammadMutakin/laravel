<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>KeuanganKu</title>
  <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('images/money-curreny-svgrepo-com (1).svg')); ?>">
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --green:        #2ecc71;
      --green-hover:  #27ae60;
      --forest:       #0d1f14;
      --forest-mid:   #0f2918;
      --forest-deep:  #0a1a0e;
      --surface:      #f5faf6;
      --card-border:  #e5ede8;
      --text-light:   #f0faf3;
      --text-muted:   #6b8f72;
      --text-accent:  #7ee8a2;
      --label-color:  #9eb8a5;
      --font-display: 'DM Serif Display', serif;
      --font-body:    'DM Sans', sans-serif;
    }

    body {
      font-family: var(--font-body);
      min-height: 100vh;
      background: #e8f5e9;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 32px 20px;
    }

    /* ── CARD WRAPPER ── */
    .kk-wrap {
      width: 100%;
      max-width: 1100px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      border-radius: 24px;
      overflow: hidden;
      box-shadow: 0 40px 100px rgba(10,26,14,0.22);
    }

    /* ── LEFT PANEL ── */
    .kk-left {
      background: var(--forest);
      padding: 52px 48px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 580px;
    }

    .kk-logo {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .kk-logo-mark {
      width: 32px;
      height: 32px;
      background: var(--green);
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    .kk-logo-text {
      font-size: 15px;
      font-weight: 500;
      color: var(--text-light);
      letter-spacing: -0.2px;
    }

    .kk-headline {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      padding: 40px 0 32px;
    }

    .kk-eyebrow {
      font-size: 11px;
      font-weight: 500;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: var(--green);
      margin-bottom: 16px;
    }

    .kk-h1 {
      font-family: var(--font-display);
      font-size: clamp(2rem, 2.6vw, 2.6rem);
      line-height: 1.15;
      color: var(--text-light);
      margin-bottom: 16px;
      font-weight: 400;
    }

    .kk-h1 em {
      font-style: italic;
      color: #7ee8a2;
    }

    .kk-sub {
      font-size: 13.5px;
      color: var(--text-muted);
      line-height: 1.75;
      max-width: 290px;
      font-weight: 300;
    }

    /* ── ACTIONS ── */
    .kk-actions {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .kk-alert {
      background: #fffbeb;
      border: 1px solid #fde68a;
      border-radius: 10px;
      padding: 11px 16px;
      font-size: 12.5px;
      color: #92400e;
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 2px;
    }

    .kk-alert-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: #f59e0b;
      flex-shrink: 0;
    }

    .kk-btn {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
      padding: 13px 20px;
      border-radius: 10px;
      font-size: 13.5px;
      font-weight: 500;
      font-family: var(--font-body);
      text-decoration: none;
      border: none;
      cursor: pointer;
      transition: background 0.18s, border-color 0.18s;
    }

    .kk-btn-primary {
      background: var(--green);
      color: var(--forest-deep);
    }

    .kk-btn-primary:hover { background: var(--green-hover); }

    .kk-btn-ghost {
      background: transparent;
      color: var(--text-accent);
      border: 1px solid #1e3d25;
    }

    .kk-btn-ghost:hover {
      border-color: var(--green);
      background: var(--forest-mid);
    }

    .kk-btn-ghost-form { width: 100%; }

    /* ── RIGHT PANEL ── */
    .kk-right {
      background: var(--surface);
      padding: 52px 48px;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .kk-card {
      background: #fff;
      border: 1px solid var(--card-border);
      border-radius: 16px;
      padding: 22px 24px;
    }

    .kk-card-label {
      font-size: 11px;
      font-weight: 500;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      color: var(--label-color);
      margin-bottom: 6px;
    }

    .kk-card-value {
      font-family: var(--font-display);
      font-size: 1.85rem;
      color: var(--forest);
      line-height: 1.1;
    }

    .kk-badge {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      background: #eaf7ef;
      color: #1e6b3a;
      border-radius: 99px;
      padding: 3px 10px;
      font-size: 11.5px;
      font-weight: 500;
      margin-top: 10px;
    }

    .kk-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--green); }

    /* mini bar chart */
    .kk-bars {
      display: flex;
      align-items: flex-end;
      gap: 5px;
      height: 48px;
      margin-top: 14px;
    }

    .kk-bar {
      flex: 1;
      border-radius: 3px 3px 0 0;
      background: #d4edda;
    }

    .kk-bar.hi { background: var(--green); }

    /* 2-col mini cards */
    .kk-grid2 {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }

    .kk-mini-card {
      background: #fff;
      border: 1px solid var(--card-border);
      border-radius: 12px;
      padding: 16px 18px;
    }

    .kk-mini-label {
      font-size: 11px;
      color: var(--label-color);
      margin-bottom: 5px;
      font-weight: 500;
      letter-spacing: 0.5px;
    }

    .kk-mini-val {
      font-size: 1.15rem;
      font-weight: 500;
      color: var(--forest);
      font-family: var(--font-display);
    }

    .kk-mini-neg { color: #c0392b; }

    /* feature list */
    .kk-feature-list {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin-top: 4px;
    }

    .kk-feature {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 13px;
      color: #3d6647;
    }

    .kk-feat-icon {
      width: 30px;
      height: 30px;
      background: #eaf7ef;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    /* ── MODAL ── */
    .kk-modal-overlay {
      position: fixed;
      inset: 0;
      background: rgba(10,26,14,0.6);
      backdrop-filter: blur(4px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 999;
    }

    .kk-modal-box {
      background: #fff;
      border-radius: 20px;
      padding: 40px 36px;
      max-width: 360px;
      width: 90%;
      text-align: center;
      box-shadow: 0 30px 80px rgba(0,0,0,0.18);
    }

    .kk-modal-icon {
      width: 52px;
      height: 52px;
      background: #eaf7ef;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 18px;
    }

    .kk-modal-title {
      font-family: var(--font-display);
      font-size: 1.25rem;
      color: var(--forest);
      margin-bottom: 8px;
    }

    .kk-modal-text {
      font-size: 13.5px;
      color: #6b7280;
      line-height: 1.65;
      margin-bottom: 24px;
    }

    .kk-progress-wrap {
      width: 100%;
      background: #f0f4f0;
      border-radius: 99px;
      height: 4px;
      overflow: hidden;
    }

    .kk-progress-bar {
      height: 100%;
      background: var(--green);
      width: 0%;
      transition: width 3s linear;
    }

    /* ── RESPONSIVE ── */
    @media (max-width: 720px) {
      .kk-wrap { grid-template-columns: 1fr; }
      .kk-right { display: none; }
      .kk-left { padding: 40px 28px; min-height: auto; }
    }
  </style>
</head>

<body>

  
  <?php if(session('modal_pending')): ?>
  <div class="kk-modal-overlay" id="kkModalOverlay">
    <div class="kk-modal-box">
      <div class="kk-modal-icon">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="#2ecc71" stroke-width="1.8"/>
          <path d="M12 8v4l2 2" stroke="#2ecc71" stroke-width="1.8" stroke-linecap="round"/>
        </svg>
      </div>
      <div class="kk-modal-title">Menunggu Persetujuan</div>
      <div class="kk-modal-text">
        Pendaftaran berhasil.<br>
        Silakan tunggu persetujuan dari admin sebelum masuk ke akun Anda.
      </div>
      <div class="kk-progress-wrap">
        <div class="kk-progress-bar" id="kkProgress"></div>
      </div>
    </div>
  </div>
  <script>
    setTimeout(() => document.getElementById('kkProgress').style.width = '100%', 50);
    setTimeout(() => document.getElementById('kkModalOverlay').remove(), 3200);
  </script>
  <?php endif; ?>

  <div class="kk-wrap">

    
    <div class="kk-left">

      
      <div class="kk-logo">
        <div class="kk-logo-mark">
            <img src="<?php echo e(asset('images/money-curreny-svgrepo-com (1).svg')); ?>" width="25" height="25" alt="KeuanganKu">
        </div>
        <span class="kk-logo-text">KeuanganKu</span>
      </div>

      
      <div class="kk-headline">
        <div class="kk-eyebrow">Manajemen Keuangan</div>
        <h1 class="kk-h1">Kelola uangmu<br>dengan <em>lebih cerdas</em></h1>
        <p class="kk-sub">Pantau pemasukan, pengeluaran, dan anggaran dalam satu tempat yang rapi dan mudah dipahami.</p>
      </div>

      
      <div class="kk-actions">

        <?php if(session('status')): ?>
          <div class="kk-alert">
            <div class="kk-alert-dot"></div>
            <span><?php echo e(session('status')); ?></span>
          </div>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
          <a href="<?php echo e(route('register.user')); ?>" class="kk-btn kk-btn-primary">
            Daftar Akun
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M3 8h10M9 4l4 4-4 4" stroke="#0a1a0e" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </a>
          <a href="<?php echo e(route('login')); ?>" class="kk-btn kk-btn-ghost">
            Masuk
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M3 8h10M9 4l4 4-4 4" stroke="#7ee8a2" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </a>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
          <a href="<?php echo e(route('dashboard')); ?>" class="kk-btn kk-btn-primary">
            Buka Dashboard
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M3 8h10M9 4l4 4-4 4" stroke="#0a1a0e" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </a>
          <form action="<?php echo e(route('logout')); ?>" method="POST" class="kk-btn-ghost-form">
            <?php echo csrf_field(); ?>
            <button type="submit" class="kk-btn kk-btn-ghost" style="width:100%;">
              Keluar
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M10 2h3a1 1 0 011 1v10a1 1 0 01-1 1h-3M7 11l4-4-4-4M11 8H3" stroke="#7ee8a2" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>
          </form>
        <?php endif; ?>

      </div>
    </div>

    
    <div class="kk-right">

      
      <div class="kk-card">
        <div class="kk-card-label">Total Saldo</div>
        <div class="kk-card-value">
          <?php if(auth()->guard()->check()): ?>
            Rp <?php echo e(number_format(auth()->user()->totalSaldo ?? 0, 0, ',', '.')); ?>

          <?php else: ?>
            Rp 12.450.000
          <?php endif; ?>
        </div>
        <div class="kk-badge">
          <div class="kk-dot"></div>
          +8,2% bulan ini
        </div>
        
        <div class="kk-bars">
          <div class="kk-bar" style="height:35%"></div>
          <div class="kk-bar" style="height:55%"></div>
          <div class="kk-bar" style="height:42%"></div>
          <div class="kk-bar" style="height:70%"></div>
          <div class="kk-bar" style="height:60%"></div>
          <div class="kk-bar hi" style="height:88%"></div>
        </div>
      </div>

      
      <div class="kk-grid2">
        <div class="kk-mini-card">
          <div class="kk-mini-label">Pemasukan</div>
          <div class="kk-mini-val">Rp 5,2jt</div>
        </div>
        <div class="kk-mini-card">
          <div class="kk-mini-label">Pengeluaran</div>
          <div class="kk-mini-val kk-mini-neg">Rp 2,8jt</div>
        </div>
      </div>

      
      <div class="kk-feature-list">
        <div class="kk-feature">
          <div class="kk-feat-icon">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <rect x="1" y="4" width="12" height="9" rx="2" stroke="#2ecc71" stroke-width="1.3"/>
              <path d="M4 4V3a3 3 0 016 0v1" stroke="#2ecc71" stroke-width="1.3" stroke-linecap="round"/>
            </svg>
          </div>
          Transaksi terenkripsi dan aman
        </div>
        <div class="kk-feature">
          <div class="kk-feat-icon">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M2 10l3-3 2 2 5-5" stroke="#2ecc71" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          Laporan keuangan otomatis
        </div>
        <div class="kk-feature">
          <div class="kk-feat-icon">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <circle cx="7" cy="7" r="5.5" stroke="#2ecc71" stroke-width="1.3"/>
              <path d="M7 4.5v3l2 1" stroke="#2ecc71" stroke-width="1.3" stroke-linecap="round"/>
            </svg>
          </div>
          Riwayat lengkap setiap saat
        </div>
      </div>

    </div>
  </div>

</body>
</html><?php /**PATH C:\laragon\www\laravel11\finance-app\resources\views/home.blade.php ENDPATH**/ ?>