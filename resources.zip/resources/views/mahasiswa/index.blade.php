<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Data Mahasiswa</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root { --green-dark:#1f4037; --green-mid:#2d6a4f; --green:#2ecc71; --navy:#1a2336; --font:'Plus Jakarta Sans',sans-serif; }
        body { font-family:var(--font); background:#f0f4f8; min-height:100vh; padding:24px; }
        .container { max-width:960px; margin:0 auto; }

        .navbar {
            background:#fff; border-radius:16px; padding:14px 20px;
            display:flex; justify-content:space-between; align-items:center;
            margin-bottom:20px; box-shadow:0 2px 12px rgba(0,0,0,.06);
        }
        .navbar-brand { font-size:1.1rem; font-weight:800; color:var(--navy); }

        .page-header {
            display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;
        }
        .page-title { font-size:1rem; font-weight:800; color:var(--navy); }
        .btn-tambah {
            background:var(--green); color:#fff; padding:9px 18px;
            border-radius:10px; font-size:0.82rem; font-weight:700;
            text-decoration:none; transition:0.2s;
        }
        .btn-tambah:hover { background:#27ae60; }

        .alert {
            padding:12px 16px; border-radius:12px; font-size:0.85rem;
            font-weight:600; margin-bottom:14px;
        }
        .alert-success { background:#d4edda; color:#155724; border:1px solid #c3e6cb; }
        .alert-danger  { background:#fdecea; color:#c0392b; border:1px solid #f5c6cb; }

        .card { background:#fff; border-radius:16px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,.06); }
        table { width:100%; border-collapse:collapse; font-size:0.88rem; }
        thead tr { background:linear-gradient(135deg,var(--green-dark),var(--green-mid)); color:#fff; }
        thead th { padding:13px 16px; text-align:left; font-weight:700; font-size:0.82rem; }
        tbody tr { border-bottom:1px solid #f0f4f8; transition:0.15s; }
        tbody tr:last-child { border-bottom:none; }
        tbody tr:hover { background:#f9fbfd; }
        tbody td { padding:13px 16px; color:var(--navy); vertical-align:middle; }
        .npm-badge {
            display:inline-block; background:#e6f4f1; color:var(--green-dark);
            padding:3px 10px; border-radius:8px; font-size:0.78rem; font-weight:700;
        }
        .prodi-badge {
            display:inline-block; background:#f0f4f8; color:#4b5563;
            padding:3px 10px; border-radius:8px; font-size:0.78rem;
        }
        .action-group { display:flex; gap:6px; }
        .btn-edit {
            padding:6px 12px; border-radius:8px; font-size:0.78rem; font-weight:600;
            background:#fff8e1; color:#b45309; text-decoration:none; transition:0.15s;
            border:1px solid #fde68a;
        }
        .btn-edit:hover { background:#fde68a; }
        .btn-hapus {
            padding:6px 12px; border-radius:8px; font-size:0.78rem; font-weight:600;
            background:#fdecea; color:#c0392b; border:1px solid #f5c6cb;
            cursor:pointer; font-family:var(--font); transition:0.15s;
        }
        .btn-hapus:hover { background:#f5c6cb; }
        .empty-state { text-align:center; padding:48px; color:#9ca3af; font-size:0.88rem; }
    </style>
</head>
<body>
<div class="container">

    <div class="navbar">
        <div class="navbar-brand">🎓 Data Mahasiswa</div>
    </div>

    @if(session('success'))
        <div class="alert alert-success">✅ {{ session('success') }}</div>
    @endif

    <div class="page-header">
        <div class="page-title">Daftar Mahasiswa</div>
        <a href="{{ route('mahasiswa.create') }}" class="btn-tambah">+ Tambah Data</a>
    </div>

    <div class="card">
        @if($data->count() > 0)
        <table>
            <thead>
                <tr>
                    <th>NPM</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Program Studi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data as $mhs)
                <tr>
                    <td><span class="npm-badge">{{ $mhs->NPM }}</span></td>
                    <td>{{ $mhs->Nama }}</td>
                    <td>{{ $mhs->Alamat ?? '-' }}</td>
                    <td><span class="prodi-badge">{{ $mhs->Program_Studi ?? '-' }}</span></td>
                    <td>
                        <div class="action-group">
                            <a href="{{ route('mahasiswa.edit', $mhs->NPM) }}" class="btn-edit">✏️ Edit</a>
                            <form action="{{ route('mahasiswa.destroy', $mhs->NPM) }}" method="POST"
                                  onsubmit="return confirm('Yakin ingin menghapus data {{ $mhs->Nama }}?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn-hapus">🗑️ Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @else
            <div class="empty-state">
                Belum ada data mahasiswa. Klik <strong>+ Tambah Data</strong> untuk menambahkan.
            </div>
        @endif
    </div>

</div>
</body>
</html>