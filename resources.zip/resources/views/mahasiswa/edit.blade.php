<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Edit Mahasiswa</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root { --green-dark:#1f4037; --green-mid:#2d6a4f; --green:#2ecc71; --navy:#1a2336; --font:'Plus Jakarta Sans',sans-serif; }
        body {
            font-family:var(--font); background:linear-gradient(135deg,#c8e6c9,#b2dfdb,#80cbc4);
            min-height:100vh; display:flex; align-items:center; justify-content:center; padding:24px;
        }
        .card {
            background:#fff; border-radius:24px; width:100%; max-width:520px;
            box-shadow:0 30px 80px rgba(20,50,40,.18); overflow:hidden;
        }
        .card-header {
            background:linear-gradient(135deg,#7f4a0a,#b45309);
            padding:28px 28px 22px; color:#fff;
        }
        .back-link {
            display:inline-flex; align-items:center; gap:5px; font-size:0.78rem;
            color:rgba(255,255,255,.7); text-decoration:none; margin-bottom:14px; font-weight:600;
        }
        .back-link:hover { color:#fff; }
        .card-title { font-size:1.2rem; font-weight:800; }
        .card-sub   { font-size:0.82rem; opacity:0.75; margin-top:2px; }
        .npm-info {
            margin-top:10px; background:rgba(255,255,255,.15); border-radius:10px;
            padding:8px 14px; font-size:0.82rem; display:inline-block;
        }
        .card-body  { padding:28px; }

        .form-group { margin-bottom:16px; }
        .form-label { display:block; font-size:0.8rem; font-weight:700; color:var(--navy); margin-bottom:6px; }
        .form-input {
            width:100%; padding:13px 14px; border-radius:12px;
            border:1.5px solid #e4eaf2; font-family:var(--font);
            font-size:0.88rem; color:var(--navy); outline:none; background:#f9fbfd; transition:0.2s;
        }
        .form-input:focus { border-color:#b45309; background:#fff; box-shadow:0 0 0 3px rgba(180,83,9,.12); }
        .form-input:disabled { background:#f0f4f8; color:#9ca3af; cursor:not-allowed; }
        .form-input.is-invalid { border-color:#e74c3c; }
        .invalid-feedback { color:#e74c3c; font-size:0.78rem; margin-top:4px; }

        .form-row { display:flex; gap:12px; }
        .form-row .form-group { flex:1; }

        .alert-error {
            background:#fdecea; color:#c0392b; border:1px solid #f5c6cb;
            padding:12px 16px; border-radius:12px; font-size:0.85rem; font-weight:600; margin-bottom:16px;
        }
        .btn-submit {
            width:100%; padding:14px; border-radius:12px; border:none;
            background:linear-gradient(135deg,#7f4a0a,#b45309);
            color:#fff; font-size:0.9rem; font-weight:700;
            cursor:pointer; font-family:var(--font); transition:0.2s; margin-top:4px;
        }
        .btn-submit:hover { opacity:0.88; transform:translateY(-1px); }
        .hint { font-size:0.75rem; color:#9ca3af; margin-top:4px; }
    </style>
</head>
<body>
<div class="card">
    <div class="card-header">
        <a href="{{ route('mahasiswa.index') }}" class="back-link">← Kembali</a>
        <div class="card-title">Edit Data Mahasiswa</div>
        <div class="card-sub">Ubah data yang diperlukan</div>
        <div class="npm-info">NPM: <strong>{{ $mhs->NPM }}</strong></div>
    </div>

    <div class="card-body">

        @if($errors->any())
            <div class="alert-error">⚠️ {{ $errors->first() }}</div>
        @endif

        <form method="POST" action="{{ route('mahasiswa.update', $mhs->NPM) }}">
            @csrf
            @method('PUT')

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">NPM</label>
                    <input type="text" class="form-input" value="{{ $mhs->NPM }}" disabled>
                    <div class="hint">NPM tidak dapat diubah</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Program Studi</label>
                    <input type="text" name="Program_Studi"
                        class="form-input @error('Program_Studi') is-invalid @enderror"
                        value="{{ old('Program_Studi', $mhs->Program_Studi) }}">
                    @error('Program_Studi')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Nama Lengkap</label>
                <input type="text" name="Nama"
                    class="form-input @error('Nama') is-invalid @enderror"
                    value="{{ old('Nama', $mhs->Nama) }}">
                @error('Nama')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="form-group">
                <label class="form-label">Alamat</label>
                <input type="text" name="Alamat"
                    class="form-input"
                    value="{{ old('Alamat', $mhs->Alamat) }}">
            </div>

            <button type="submit" class="btn-submit">💾 Simpan Perubahan</button>
        </form>

    </div>
</div>
</body>
</html>