<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>KeuanganKu – Transaksi</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --green-dark: #1f4037; --green-mid: #2d6a4f; --green: #2ecc71;
            --navy: #1a2336; --font: 'Plus Jakarta Sans', sans-serif;
        }
        body { font-family: var(--font); background: #f0f4f8; min-height: 100vh; padding: 24px; }
        .container { max-width: 860px; margin: 0 auto; }

        /* Navbar */
        .navbar {
            background: #fff; border-radius: 16px; padding: 14px 20px;
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 20px; box-shadow: 0 2px 12px rgba(0,0,0,0.06);
        }
        .navbar-brand { font-size: 1.1rem; font-weight: 800; color: var(--navy); }
        .navbar-right { display: flex; align-items: center; gap: 12px; }
        .nav-user { font-size: 0.82rem; color: #6b7280; }
        .btn-logout {
            padding: 7px 14px; border-radius: 10px; font-size: 0.8rem; font-weight: 600;
            background: #fdecea; color: #c0392b; border: none; cursor: pointer;
            font-family: var(--font); text-decoration: none;
        }

        /* Saldo card */
        .saldo-card {
            background: linear-gradient(135deg, var(--green-dark), var(--green-mid));
            color: #fff; border-radius: 20px; padding: 28px 28px 24px;
            margin-bottom: 20px; position: relative; overflow: hidden;
        }
        .saldo-card::after {
            content: ''; position: absolute; top: -40px; right: -40px;
            width: 160px; height: 160px; border-radius: 50%;
            background: rgba(255,255,255,0.05);
        }
        .saldo-label { font-size: 0.82rem; opacity: 0.8; margin-bottom: 6px; }
        .saldo-amount { font-size: 2rem; font-weight: 800; }
        .saldo-sub { font-size: 0.78rem; opacity: 0.65; margin-top: 4px; }

        /* Header row */
        .list-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 14px;
        }
        .list-title { font-size: 0.95rem; font-weight: 700; color: var(--navy); }
        .btn-tambah {
            background: var(--green); color: #fff; padding: 9px 18px;
            border-radius: 10px; font-size: 0.82rem; font-weight: 700;
            text-decoration: none; transition: 0.2s;
        }
        .btn-tambah:hover { background: #27ae60; }

        /* Flash */
        .alert {
            padding: 12px 16px; border-radius: 12px; font-size: 0.85rem;
            font-weight: 600; margin-bottom: 14px;
        }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }

        /* List */
        .list-card { background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.06); }
        .tx-item {
            display: flex; justify-content: space-between; align-items: center;
            padding: 14px 20px; border-bottom: 1px solid #f0f4f8;
        }
        .tx-item:last-child { border-bottom: none; }
        .tx-cat { font-size: 0.88rem; font-weight: 600; color: var(--navy); }
        .tx-date { font-size: 0.78rem; color: #9ca3af; margin-top: 2px; }
        .tx-desc { font-size: 0.75rem; color: #b0b8c1; margin-top: 1px; }
        .tx-amount { font-size: 0.95rem; font-weight: 700; }
        .income  { color: #16a34a; }
        .expense { color: #dc2626; }
        .empty { padding: 40px; text-align: center; color: #9ca3af; font-size: 0.88rem; }
    </style>
</head>
<body>
<div class="container">

    {{-- Navbar --}}
    <div class="navbar">
        <div class="navbar-brand">💰 KeuanganKu</div>
        <div class="navbar-right">
            <span class="nav-user">Halo, {{ auth()->user()->name }}</span>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="btn-logout">Logout</button>
            </form>
        </div>
    </div>

    {{-- Flash --}}
    @if(session('success'))
        <div class="alert alert-success">✅ {{ session('success') }}</div>
    @endif

    {{-- Saldo --}}
    <div class="saldo-card">
        <div class="saldo-label">Total Saldo</div>
        <div class="saldo-amount">
            {{ $totalBalance >= 0 ? '' : '-' }}Rp {{ number_format(abs($totalBalance), 0, ',', '.') }}
        </div>
        <div class="saldo-sub">{{ $transactions->count() }} transaksi tercatat</div>
    </div>

    {{-- List header --}}
    <div class="list-header">
        <div class="list-title">Riwayat Transaksi</div>
        <a href="{{ route('transactions.create') }}" class="btn-tambah">+ Tambah</a>
    </div>

    {{-- List --}}
    <div class="list-card">
        @forelse($transactions as $t)
            <div class="tx-item">
                <div>
                    <div class="tx-cat">{{ $t->category->name ?? '-' }}</div>
                    <div class="tx-date">{{ $t->transaction_date->format('d M Y') }}</div>
                    @if($t->description)
                        <div class="tx-desc">{{ $t->description }}</div>
                    @endif
                </div>
                <div class="tx-amount {{ $t->category->type === 'income' ? 'income' : 'expense' }}">
                    {{ $t->category->type === 'income' ? '+' : '-' }}Rp {{ number_format($t->amount, 0, ',', '.') }}
                </div>
            </div>
        @empty
            <div class="empty">Belum ada transaksi. Yuk tambah yang pertama!</div>
        @endforelse
    </div>

</div>
</body>
</html>