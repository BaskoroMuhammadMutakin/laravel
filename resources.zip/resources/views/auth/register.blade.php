@extends('layouts.auth')
@section('title', 'Daftar')

@section('left')
  <a href="{{ route('welcome') }}" class="back-link">← Kembali</a>
  <div class="page-title">Daftar Akun</div>
  <div class="page-sub">Isi data diri kamu untuk mendaftar</div>

  @if($errors->any())
    <div class="alert alert-error">⚠️ {{ $errors->first() }}</div>
  @endif

  <form method="POST" action="{{ route('daftar.post') }}">
    @csrf
    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" name="nama" class="form-input @error('nama') is-invalid @enderror"
               placeholder="John Doe" value="{{ old('nama') }}">
        @error('nama')<div class="invalid-feedback">{{ $message }}</div>@enderror
      </div>
      <div class="form-group">
        <label class="form-label">NIK</label>
        <input type="text" name="nik" class="form-input @error('nik') is-invalid @enderror"
               placeholder="3271xxxxxxxx" maxlength="16" value="{{ old('nik') }}">
        @error('nik')<div class="invalid-feedback">{{ $message }}</div>@enderror
      </div>
    </div>

    <div class="form-group">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-input @error('email') is-invalid @enderror"
             placeholder="email@example.com" value="{{ old('email') }}">
      @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="form-row">
      <div class="form-group">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-input @error('password') is-invalid @enderror"
               placeholder="••••••••">
        @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
      </div>
      <div class="form-group">
        <label class="form-label">Konfirmasi Password</label>
        <input type="password" name="password_confirmation" class="form-input" placeholder="••••••••">
      </div>
    </div>

    <button type="submit" class="btn btn-green" style="margin-top:6px;">✅ Daftar Sekarang</button>
  </form>
@endsection