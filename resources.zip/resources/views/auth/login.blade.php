@extends('layouts.auth')
@section('title', 'Login')

@section('left')
  <a href="{{ route('welcome') }}" class="back-link">← Kembali</a>
  <div class="page-title">Login</div>
  <div class="page-sub">Masuk dengan NIK dan password kamu</div>

  @if($errors->any())
    <div class="alert alert-error">❌ {{ $errors->first() }}</div>
  @endif

  <form method="POST" action="{{ route('login.post') }}">
    @csrf
    <div class="form-group">
      <label class="form-label">NIK</label>
      <input type="text" name="nik" class="form-input @error('nik') is-invalid @enderror"
             placeholder="3271xxxxxxxx" maxlength="16" value="{{ old('nik') }}">
      @error('nik')<div class="invalid-feedback">{{ $message }}</div>@enderror
    </div>

    <div class="form-group">
      <label class="form-label">Password</label>
      <input type="password" name="password" class="form-input" placeholder="••••••••">
    </div>

    <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;">
      <input type="checkbox" name="remember" id="remember" style="accent-color:var(--green);">
      <label for="remember" style="font-size:0.82rem;color:#6b7280;font-weight:500;">Ingat saya</label>
    </div>

    <button type="submit" class="btn btn-green">🔐 Masuk</button>
  </form>
@endsection