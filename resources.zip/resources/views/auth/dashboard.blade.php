<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>KeuanganKu – Tambah Transaksi</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --green-dark: #1f4037; --green-mid: #2d6a4f; --green: #2ecc71;
            --navy: #1a2336; --font: 'Plus Jakarta Sans', sans-serif;
        }
        body {
            font-family: var(--font); background: linear-gradient(135deg, #c8e6c9, #b2dfdb, #80cbc4);
            min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px;
        }
        .card {
            background: #fff; border-radius: 24px; width: 100%; max-width: 500px;
            box-shadow: 0 30px 80px rgba(20,50,40,0.18); overflow: hidden;
        }
        .card-header {
            background: linear-gradient(135deg, var(--green-dark), var(--green-mid));
            padding: 28px 28px 22px; color: #fff;
        }
        .back-link {
            display: inline-flex; align-items: center; gap: 5px;
            font-size: 0.78rem; color: rgba(255,255,255,0.7); text-decoration: none;
            margin-bottom: 14px; font-weight: 600;
        }
        .back-link:hover { color: #fff; }
        .card-title { font-size: 1.2rem; font-weight: 800; }
        .card-sub   { font-size: 0.82rem; opacity: 0.75; margin-top: 2px; }
        .card-body  { padding: 28px; }

        .form-group { margin-bottom: 16px; }
        .form-label { display: block; font-size: 0.8rem; font-weight: 700; color: var(--navy); margin-bottom: 6px; }
        .form-input, .form-select {
            width: 100%; padding: 13px 14px; border-radius: 12px;
            border: 1.5px solid #e4eaf2; font-family: var(--font);
            font-size: 0.88rem; color: var(--navy); outline: none;
            background: #f9fbfd; transition: 0.2s; appearance: none;
        }
        .form-input:focus, .form-select:focus {
            border-color: var(--green);
            background: #fff;
            box-shadow: 0 0 0 3px rgba(46,204,113,0.12);
        }
        .form-input.is-invalid, .form-select.is-invalid { border-color: #e74c3c; }
        .invalid-feedback { color: #e74c3c; font-size: 0.78rem; margin-top: 4px; }

        .alert-error {
            background: #fdecea; color: #c0392b; border: 1px solid #f5c6cb;
            padding: 12px 16px; border-radius: 12px; font-size: 0.85rem;
            font-weight: 600; margin-bottom: 16px;
        }
        .btn-submit {
            width: 100%; padding: 14px; border-radius: 12px; border: none;
            background: linear-gradient(135deg, var(--green-dark), var(--green-mid));
            color: #fff; font-size: 0.9rem; font-weight: 700;
            cursor: pointer; font-family: var(--font); transition: 0.2s; margin-top: 4px;
        }
        .btn-submit:hover { opacity: 0.88; transform: translateY(-1px); }

        /* Badge type indicator */
        .type-badge {
            display: inline-block; font-size: 0.72rem; font-weight: 700;
            padding: 2px 8px; border-radius: 8px; margin-left: 6px; vertical-align: middle;
        }
        .income-badge  { background: #d4edda; color: #155724; }
        .expense-badge { background: #fdecea; color: #c0392b; }
    </style>
</head>
<body>
<div class="card">
    <div class="card-header">
        <a href="{{ route('transactions.index') }}" class="back-link">← Kembali</a>
        <div class="card-title">Tambah Transaksi</div>
        <div class="card-sub">Catat pemasukan atau pengeluaran kamu</div>
    </div>

    <div class="card-body">

        @if($errors->any())
            <div class="alert-error">⚠️ {{ $errors->first() }}</div>
        @endif

        {{-- Form action DIPERBAIKI: pakai named route --}}
        <form method="POST" action="{{ route('transactions.store') }}">
            @csrf

            <div class="form-group">
                <label class="form-label">Kategori</label>
                <select name="category_id" class="form-select @error('category_id') is-invalid @enderror">
                    <option value="">-- Pilih Kategori --</option>
                    @foreach($categories as $c)
                        <option value="{{ $c->id }}" {{ old('category_id') == $c->id ? 'selected' : '' }}>
                            {{ $c->name }}
                            ({{ $c->type === 'income' ? 'Pemasukan' : 'Pengeluaran' }})
                        </option>
                    @endforeach
                </select>
                @error('category_id')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label class="form-label">Jumlah (Rp)</label>
                <input type="number" name="amount" placeholder="Contoh: 50000"
                    class="form-input @error('amount') is-invalid @enderror"
                    value="{{ old('amount') }}" min="1">
                @error('amount')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label class="form-label">Tanggal Transaksi</label>
                <input type="date" name="transaction_date"
                    class="form-input @error('transaction_date') is-invalid @enderror"
                    value="{{ old('transaction_date', date('Y-m-d')) }}">
                @error('transaction_date')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label class="form-label">Keterangan <span style="font-weight:400;color:#9ca3af;">(opsional)</span></label>
                <input type="text" name="description" placeholder="Contoh: Makan siang, bayar listrik..."
                    class="form-input" value="{{ old('description') }}">
            </div>

            <button type="submit" class="btn-submit">💾 Simpan Transaksi</button>
        </form>

    </div>
</div>
</body>
</html>